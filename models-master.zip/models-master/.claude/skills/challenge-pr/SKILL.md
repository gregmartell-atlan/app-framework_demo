---
description: Devil's advocate PR review for typedef changes — find what will break production tenants permanently
---

# /challenge-pr — Devil's Advocate PR Review

You are a senior engineer who believes this PR should NOT be merged. Your job is to make the strongest possible case against merging. Do not soften findings — if something will corrupt data on every Atlan tenant with no rollback, say so directly.

This is NOT a normal code review. A normal review says "maybe add a description." You say "this attribute name collides with an inherited attribute from Asset, and once deployed it will shadow the parent attribute on every tenant forever."

**Remember: typedefs are immutable once deployed. Every finding is a permanent, irreversible production change.**

---

## Step 1: Gather the Diff

Determine what to review:

1. If the user provided a PR number or URL → `gh pr diff <number>`
2. If on a feature branch → `git diff $(git merge-base HEAD master)..HEAD`
3. Otherwise → `git diff --staged` or `git diff`

Read every changed `.pkl` file in full (not just the diff) to understand the type hierarchy context. Also read the parent typedef imports to understand inherited attributes.

---

## Step 2: Attack Vectors

Systematically try to break the typedef changes across these dimensions. For each finding, describe the **exact failure scenario** — not just "this could be a problem."

### Immutability Violations

- Attributes that will have ugly, confusing, or incorrect names forever
- Type names that are ambiguous or will collide with future connectors
- Descriptions that are wrong, misleading, or empty — they cannot be corrected after deploy
- Attribute types that are wrong (e.g. `string` when it should be `long`) — cannot be changed
- Cardinality mismatches (SINGLE vs SET) — cannot be changed after deploy

### Attribute Conflicts & Shadowing

- Attributes that shadow inherited attributes from supertypes (walk the full chain: Asset → Catalog → SQL → etc.)
- Double-prefixed attribute names (manual prefix + auto `attrPrefix`)
- Attribute names that violate camelCase or use underscores
- Attributes duplicated across sibling types that should be in the supertype

### Relationship Integrity

- Relationships using `LegacyRelationship` instead of typed `ContainmentRelationship`/`PeerToPeerRelationship`
- Relationship endpoints referencing wrong types or using string literals instead of `getType()`
- Missing inverse relationships (parent without children, or vice versa)
- Containment relationships where peer-to-peer is more appropriate (or vice versa)

### Elasticsearch & Scale Impact

- Adding >20 attributes to a widely-inherited supertype (Asset, Catalog, SQL)
- Attributes with `indexType` that will bloat the ES mapping
- Types that will generate excessive ES fields across the hierarchy

### Version & Deployment Safety

- Missing version bumps on modified types
- New types not at version `"1.0"`
- Missing `Asset.pkl` typeVersion bump when adding attributes to existing types
- `draftIteration` left in code headed for production

### Hierarchy & Design

- Types that duplicate existing types (check all `typedefs/*.pkl` for overlap)
- Related types split across multiple files instead of one file per connector
- Note: `sourceModule` is auto-set by the toolkit — do NOT flag it as missing
- Incorrect `modelOutputLocation` (JSON lands in wrong directory)

### Generated JSON Sync

- JSON under `atlas/` that doesn't match what `pkl eval` would produce
- Manual edits to JSON files (should always be generated from Pkl)

---

## Step 3: Strongest Case Against Merging

Write the output in this format:

```markdown
## Devil's Advocate Review

### The Case Against Merging

<2-3 sentence summary of the most serious concern. Be direct. Remember: these changes are PERMANENT.>

### Findings

#### [BLOCK] <title> — <file:line>

**Scenario:** <Exact sequence of events that triggers the failure>
**Impact:** <What happens to every Atlan tenant when this deploys — remember, no rollback>
**Evidence:** <Quote the specific code and explain why it's wrong>

#### [RISK] <title> — <file:line>

**Scenario:** ...
**Impact:** ...
**Evidence:** ...

#### [SMELL] <title> — <file:line>

**Scenario:** ...
**Impact:** ...
**Evidence:** ...

### Verdict

<One of:>
- **DO NOT MERGE** — [reason]. Fix [specific items] first.
- **MERGE WITH CAUTION** — No blockers, but [risks] should be tracked.
- **CLEAN** — I tried hard to break this and couldn't. Ship it.
```

Severity levels:

- **[BLOCK]** — This will permanently corrupt data or break tenants. Must fix before merge. No rollback exists.
- **[RISK]** — This will cause confusion, tech debt, or limits issues. Should fix before merge.
- **[SMELL]** — Not broken today, but makes the next typedef harder or uglier.

---

## Rules

- Every finding must include a concrete failure scenario, not just "this could be bad."
- If you can't find real issues, say so honestly — a forced "CLEAN" verdict is more useful than fabricated concerns.
- Focus on permanence: what will every Atlan tenant live with forever?
- Read parent typedefs and the full supertype chain — attribute conflicts hide at inheritance boundaries.
- Run `pkl eval typedefs/<Changed>.pkl` to verify compilation before concluding.
- Check for attribute name collisions by running `pkl eval -x "TypeHierarchy.getAllSupertypeAttributes(this)" typedefs/<Changed>.pkl` if available.

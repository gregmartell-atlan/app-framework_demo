---
description: Scaffold a new Pkl typedef for a connector or service, following project conventions
---

# Create Typedef

Scaffolds a new `typedefs/<Name>.pkl` file with entity types, attributes, and relationships, then generates the JSON output.

## Usage

- `/create-typedef Confluence` — create a typedef for Confluence under SaaS
- `/create-typedef Redshift SQL` — create a typedef for Redshift under SQL
- `/create-typedef Jira SaaS <path-to-output-format>` — derive typedef from an output format file

The first argument is the service name (PascalCase). The optional second argument is the parent category. The optional third argument is a path to an output format file.

## Instructions

### 1. Gather requirements

Check if the user provided an **output format file** (JSON, YAML, or similar schema). If so, skip to step 1b. Otherwise, ask the user for:

- **Service name** (PascalCase, e.g. `Confluence`, `Redshift`)
- **Parent supertype** — one of:
  - `SaaS` — SaaS applications (Slack, Salesforce, Confluence, etc.)
  - `BI` — business intelligence (Looker, Tableau, PowerBI, etc.)
  - `SQL` — relational databases (Snowflake, Bigquery, Databricks, etc.)
  - `NoSQL` — NoSQL databases (Cassandra, DocumentDB, etc.)
  - `ObjectStore` — object stores (S3, ADLS, GCS, etc.)
  - `EventStore` — event stores (Kafka, etc.)
  - `Cloud` — cloud infrastructure (AWS, Azure, Google)
  - Or a specific typedef like `SQL.pkl` for SQL subtypes
- **Entity types** — list of asset types to create (e.g. Space, Page, User)
- **Key attributes** per entity type
- **Relationships** — containment (parent→children) and peer-to-peer associations

If the user provides a link to API docs or a schema, read it to derive entity types and attributes.

### 1b. Derive typedefs from an output format file

If the user provides an output format file (JSON schema, API response, transform YAML, connector output config, Iceberg schema, etc.), read it and automatically derive entity types, attributes, and relationships.

**Supported input formats:**

- **JSON / JSON Schema** — extract entity types from top-level keys or `$defs`/`definitions`; attributes from properties/fields
- **YAML** (e.g. `transform.yaml`, `metadata_extract.yaml`) — extract entity types from transform targets or output mappings; attributes from field mappings
- **API response samples** — extract entity types from response object structure; attributes from field names and infer types from values
- **CSV / tabular schemas** — extract entity types from sheet/table names; attributes from column headers
- **Iceberg schemas** — extract entity types from table definitions; attributes from column definitions with types

**Derivation rules:**

1. **Read the file** and identify all distinct entity types (objects, tables, resources)
2. **For each entity type**, extract attributes:
   - Map source field names to camelCase Pkl attribute names with the entity-type prefix (e.g. `space_key` → `spaceKey`)
   - Infer Pkl types from the source:
     - String/text/varchar → `"string"`
     - Integer/int/number → `"long"` (prefer `long` over `int` unless the domain is strictly tiny)
     - Boolean/bool → `"boolean"`
     - Timestamp/datetime/date → `"date"`
     - Float/double/decimal → `"double"` (prefer `double` over `float` unless the domain is strictly tiny)
     - Array/list of strings → `"string"` with `multiValued = true` (do NOT set type to `array<string>` directly)
     - Map/dict/object → `"map<string,string>"`
   - Use field descriptions from the source if available; otherwise generate concise descriptions
3. **Infer relationships** from the structure:
   - Foreign key fields (e.g. `space_id` on a Page) → ContainmentRelationship (Space→Pages)
   - Many-to-many join tables or array references → PeerToPeerRelationship
   - Parent-child nesting in the schema → ContainmentRelationship
   - Self-references (e.g. `parent_page_id` on Page) → self-referential ContainmentRelationship
4. **Remove redundant ID attributes** that are fully captured by a relationship (e.g. don't keep `pageSpaceId` if there's a `spaceAndPages` relationship), unless the ID serves a purpose beyond navigation (e.g. external system ID needed for sync)
5. **Present the derived model** to the user for confirmation before generating the Pkl file:
   - List entity types with their attributes
   - List inferred relationships
   - Flag any ambiguous decisions (e.g. "Is X a containment or peer-to-peer relationship?")

### 2. Validate against best practices

Before generating any code, review the `/typedef-best-practices` skill (`.claude/skills/typedef-best-practices/SKILL.md`) and enforce these rules:

- **Reuse existing types**: Check `typedefs/` for existing types that cover the use case before creating new ones. Parallel hierarchies that duplicate existing semantics will be rejected.
- **Group related types in one file**: Do not create separate Pkl files for related types. One file per logical connector or domain.
- **Shared attributes belong in supertypes**: If two sibling types share the same attribute, it belongs in their common supertype.
- **Namespace naming must be unambiguous**: Use full connector/domain name (e.g. `SnowflakeStream` not `Stream`). Always use `getTypeName()`.
- **No manual attribute prefix**: The toolkit auto-prefixes with `attrPrefix`. Do not double-prefix.
- **Typed relationships only**: Use `ContainmentRelationship` or `PeerToPeerRelationship` with `getType()`. Never use `LegacyRelationship` or string-based endpoint types.
- **New types start at version `"1.0"`**.
- **Descriptions**: Must start with a capital letter and end with a period.
- **No `draftIteration` in production types**: Only use during WIP iteration; remove before merging to master.
- **ES field limit awareness**: Flag if adding more than ~20 new attributes to a widely-inherited supertype.

### 3. Determine the parent import and supertype reference

**For catalog subtypes** (SaaS, BI, NoSQL, ObjectStore, EventStore):

```pkl
import "./CatalogSupertypes.pkl" as Catalog

supertypeDefinition {
  superTypes { Catalog.types["SaaS"] }  // or "BI", "NoSQL", etc.
}
```

The `modelOutputLocation` is `"Referenceable/Asset/Catalog/<Parent>"`, e.g. `"Referenceable/Asset/Catalog/SaaS"`.

**For SQL subtypes** (extending SQL directly):

```pkl
import "./SQL.pkl" as SQL

supertypeDefinition {
  superTypes { SQL.supertypeDefinition }
}
```

The `modelOutputLocation` is `"Referenceable/Asset/Catalog/SQL"`.

**For other parents** (extending a specific typedef):

```pkl
import "./<Parent>.pkl" as Parent

supertypeDefinition {
  superTypes { Parent.supertypeDefinition }
}
```

### 4. Create the Pkl file

Create `typedefs/<Name>.pkl` following this template:

```pkl
/* SPDX-License-Identifier: Apache-2.0
   Copyright 2024 Atlan Pte. Ltd. */
amends "../toolkit/src/main/pkl/Typedefs.pkl"

import "./CatalogSupertypes.pkl" as Catalog  // or the appropriate parent

namespace = "<Name>"
modelOutputLocation = "Referenceable/Asset/Catalog/<Parent>"

supertypeDefinition {
  description = "Base class for <Name> assets."
  superTypes { Catalog.types["<Parent>"] }
}

// Local type name variables
local MyEntity = getTypeName("MyEntity")

customAssetTypes {
  [MyEntity] {
    description = "Instance of a <Name> MyEntity in Atlan."
    version = "1.0"
    attributes {
      ["myAttribute"] {
        description = "Description of the attribute."
        type = "string"  // string, long, boolean, date, double, map<string,string>
        // For multi-valued attributes: type = "string" with multiValued = true
      }
    }
  }
}

customRelationshipTypes {
  // ContainmentRelationship for parent-child ownership
  ["parentAndChildren"] = new ContainmentRelationship {
    parent {
      type = module.getType(ParentEntity)
      attribute = "parent"
      description = "Parent that contains this child."
    }
    children {
      type = module.getType(ChildEntity)
      attribute = "children"
      description = "Children in this parent."
    }
  }
  // PeerToPeerRelationship for N:M associations
  ["entityAAndEntityB"] = new PeerToPeerRelationship {
    peers {
      new {
        type = module.getType(EntityA)
        attribute = "entityBs"
        description = "EntityBs associated with this EntityA."
      }
      new {
        type = module.getType(EntityB)
        attribute = "entityAs"
        description = "EntityAs associated with this EntityB."
      }
    }
    manyToMany = true
  }
}
```

### 5. Naming conventions

- **Namespace**: PascalCase service name (e.g. `Confluence`, `Snowflake`)
- **Entity type locals**: short name without namespace prefix (e.g. `local Space = getTypeName("Space")`)
- **Attribute keys**: camelCase, prefixed with the entity type in lowercase (e.g. `spaceKey`, `pageTitle`, `blogpostStatus`)
  - This prefix uses the **short entity name**, not the full prefixed name
  - The framework automatically adds the namespace prefix in generated JSON (e.g. `confluenceSpaceKey`)
- **Relationship keys**: camelCase describing both sides (e.g. `spaceAndPages`, `pageAndLabels`)
- **Relationship attributes**: camelCase, singular for SINGLE cardinality (parent side), plural for SET cardinality (children side)
- **Descriptions**: present tense, end with a period

### 6. Validate and generate

Run:

```bash
pkl eval typedefs/<Name>.pkl -m .
```

This must complete without errors. Review the generated JSON files under `atlas/entityDefs/` to confirm correctness.

### 7. Lint

Run:

```bash
npx pretty-quick
```

### 8. Report

Show the user:

- List of entity types created
- List of relationships created
- The generated file paths
- Any decisions made about attribute types or relationship modeling

## Common attribute types

| Pkl type               | Modifiers            | Use for                                                              |
| ---------------------- | -------------------- | -------------------------------------------------------------------- |
| `"string"`             |                      | Names, IDs, descriptions, statuses                                   |
| `"long"`               |                      | Numeric values — prefer over `int` unless domain is strictly tiny    |
| `"int"`                |                      | Only for small bounded integers (e.g. position, count < 2B)          |
| `"boolean"`            |                      | Flags, toggles                                                       |
| `"date"`               |                      | Timestamps, dates                                                    |
| `"double"`             |                      | Decimal numbers — prefer over `float` unless domain is strictly tiny |
| `"string"`             | `multiValued = true` | Lists of tags, IDs (renders as `array<string>` in Atlas)             |
| `"map<string,string>"` |                      | Key-value metadata                                                   |

**Important:** Never set `type = "array<string>"` directly. Use `type = "string"` with `multiValued = true` instead — the toolkit handles the array wrapping.

## Cross-module references

When referencing types from other modules:

```pkl
import "./SQL.pkl" as SQL

// Reference a type from another module
type = SQL.getType("Schema")

// Reference an enum from another module
enum = SQL.getEnum("TableType")

// Reference a struct from another module
struct = DQ.getStruct("RuleConfigArguments")
```

---
description: Structured code review for typedef PRs — CI checks, hierarchy validation, and design review
---

# /review-pr — Typedef PR Review

Structured review for typedef PRs. Covers CI validation, hierarchy correctness, and design quality.

## Usage

- `/review-pr` — review current branch diff against master
- `/review-pr 1234` — review PR #1234
- `/review-pr https://github.com/atlanhq/models/pull/1234` — review PR by URL

---

## Step 1: Gather Context

1. Get the diff (same as challenge-pr step 1)
2. Read every changed `.pkl` file in full
3. Read the parent typedef imports to understand the supertype chain
4. List all new/modified entity types, attributes, relationships, enums, and structs

---

## Step 2: CI Validation (Automated Checks)

Run or simulate these checks and report pass/fail:

### Hard Constraints

- [ ] All `.pkl` files compile: `pkl eval typedefs/<Changed>.pkl -m .`
- [ ] Type names are PascalCase
- [ ] Attribute names are camelCase (no underscores, no ALL_CAPS)
- Note: `sourceModule` is auto-set by the toolkit — do NOT check for or suggest adding it manually

### Version Check

- [ ] New types at version `"1.0"`
- [ ] Modified types have version bumped
- [ ] `Asset.pkl` typeVersion bumped if attributes added to existing types

### Attribute Conflicts

- [ ] No duplicate attribute names within a type (including inherited)
- [ ] No type conflicts across the hierarchy (e.g. `string` in parent, `int` in child)
- [ ] No `draftIteration` in production-bound types

### Legacy Constructs

- [ ] No new `LegacyRelationship` (use `ContainmentRelationship` or `PeerToPeerRelationship`)
- [ ] No new `LegacyAttributeDef` in the diff — scan every added line for `new LegacyAttributeDef`. This is a CI FAIL regardless of context: adding a new attribute to an existing legacy type (e.g. `legacyAssetTypes`) still requires standard `AttributeDef`. `LegacyAttributeDef` is for backwards-compat on already-deployed attributes only — a CI flag here is never a false positive.
- [ ] No string-based `superTypes` (use typed references)

### JSON Sync

- [ ] Generated JSON matches Pkl source: run `/regenerate-typedefs` and verify no diff

---

## Step 3: Design Review (Human Judgment)

### Hierarchy Correctness

- Is the parent supertype the right choice? (SaaS vs BI vs SQL vs etc.)
- Are shared attributes in the common supertype, not duplicated in leaves?
- Is `modelOutputLocation` correct for the hierarchy?

### Naming Quality

- Are type names globally unambiguous? (e.g. `SnowflakeStream` not `Stream`)
- Are attribute names clear and correctly prefixed with entity short name?
- Are relationship names descriptive of both sides?

### Relationship Design

- Are containment relationships used for true parent-child ownership?
- Are peer-to-peer relationships used for associations?
- Are cardinalities correct? (SINGLE for parent side, SET for children)
- Are relationship attribute names singular/plural as appropriate?

### Completeness

- Are all entity types that should exist for this connector present?
- Are key attributes present for each type?
- Are all necessary relationships defined?
- Are descriptions present, capitalized, and ending with a period?

---

## Step 4: Output

```markdown
## PR Review: <PR title or branch name>

### Summary

<1-2 sentence summary of what this PR does>

### CI Checks

| Check               | Status    | Notes |
| ------------------- | --------- | ----- |
| Pkl compilation     | PASS/FAIL | ...   |
| Naming conventions  | PASS/FAIL | ...   |
| Version check       | PASS/FAIL | ...   |
| Attribute conflicts | PASS/FAIL | ...   |
| Legacy constructs   | PASS/FAIL | ...   |
| JSON sync           | PASS/FAIL | ...   |

### Design Findings

#### <severity> <title> — <file:line>

<description and recommendation>

### Recommendation

- **APPROVE** — CI passes, design is sound.
- **REQUEST CHANGES** — [list specific items to fix].
- **NEEDS DISCUSSION** — [ambiguous design decisions to resolve].
```

Severity: **Critical** (must fix), **Warning** (should fix), **Suggestion** (nice to have).

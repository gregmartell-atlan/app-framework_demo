---
description: Regenerate all Atlas type definitions from Pkl source files and lint the output
---

# Regenerate Typedefs

Regenerates all Atlas type definitions from Pkl source files and lints the output.

## Usage

- `/regenerate-typedefs` - Regenerate all typedefs (JSON only)
- `/regenerate-typedefs python` - Regenerate all typedefs including Python SDK generation
- `/regenerate-typedefs java` - Regenerate all typedefs including Java SDK generation

## Instructions

1. Change to the repository root directory (atlanhq/models)

2. Run the Pkl evaluation command:

   - **Default mode** (no arguments): `pkl eval typedefs/*.pkl -m .`
   - **Python SDK mode** (when args contain "python"): `pkl eval typedefs/*.pkl -m . -p sdk=python`
   - **Java SDK mode** (when args contain "java"): `pkl eval typedefs/*.pkl -m . -p sdk=java`

3. After the Pkl command completes successfully, regenerate the docs JSON:
   `pkl eval toolkit/src/main/pkl/DocsRenderer.pkl -m .`

4. Ensure `node_modules` is present so the linter uses the repo-pinned prettier, then run the linter:

   - Install deps if missing: `[ -d node_modules ] || npm install --no-audit --no-fund`
   - Run pretty-quick via the local binary: `node_modules/.bin/pretty-quick`

5. Report a summary of what was regenerated and any errors encountered.

## Notes

- The `-m .` flag outputs files to the current directory structure
- The `-p sdk=python` parameter enables Python SDK code generation in addition to JSON typedefs
- The `-p sdk=java` parameter enables Java SDK code generation in addition to JSON typedefs
- DocsRenderer outputs one JSON file per type to `docs/types/` (e.g. `docs/types/snowflake-table.json`)
- `pretty-quick` formats all staged/changed files according to the project's Prettier config
- Always invoke `node_modules/.bin/pretty-quick` rather than `npx pretty-quick`. Without a local `node_modules`, `npx` resolves a different prettier version whose JSON formatting (e.g. multi-line vs. inline single-element arrays) diverges from the pinned `prettier@^3.6.2` used by CI's `npm run lint-check`, producing files that silently fail CI.

---
description: Pre-implementation design review for new typedefs — challenge assumptions before writing permanent code
---

# /design-review — Typedef Design Review

You are a staff engineer reviewing a proposed typedef design BEFORE implementation. Your goal is to prevent permanent mistakes by challenging assumptions, mapping blast radius, and identifying 3+ ways the proposed design could fail.

**This happens before any Pkl code is written.** Once typedefs deploy, they are permanent.

## Usage

- `/design-review` — review a design described in conversation
- `/design-review <file>` — review a design doc, output format file, or draft Pkl file

---

## Step 1: Understand the Proposal

Gather or confirm:

1. **What connector/service** is being modeled?
2. **What entity types** are proposed?
3. **What is the parent supertype** (SaaS, SQL, BI, etc.)?
4. **What attributes** are planned for each type?
5. **What relationships** connect the types?

If the user provided a file (output format, API schema, draft Pkl), read it and extract the above.

---

## Step 2: Challenge the Design

### Hierarchy Placement

- Is this the right parent supertype? Could it belong elsewhere?
- Does this connector share semantics with an existing connector that should be reused?
- Check `typedefs/*.pkl` for any existing types that overlap with the proposal.

### Entity Type Granularity

- Are there too many types? (Over-modeling creates permanent ES field bloat)
- Are there too few types? (Under-modeling means attributes crammed into one type)
- Should any proposed types be attributes instead of separate entities?
- Should any proposed attributes be separate entities instead?

### Attribute Design

- Are attribute types correct? (Can't change after deploy)
  - Will `string` be sufficient, or should it be `long` for numeric IDs?
  - Should lists use `array<string>` or a relationship?
  - Are timestamps `date` not `string`?
- Are attribute names clear and unambiguous across the full hierarchy?
- Will the auto-prefix (`attrPrefix` + attribute key) produce sensible names?
- How many attributes total? Flag if >20 new attributes on a supertype.

### Relationship Design

- Is each relationship the right type? (Containment vs peer-to-peer)
- Are there missing relationships? (Orphaned types with no navigation path)
- Are there circular containment relationships? (A contains B contains A)
- Self-referential relationships — are they needed? (e.g. parent page → child page)

### Naming

- Will type names be globally unambiguous in 2 years when 50 more connectors exist?
- Do attribute names make sense outside the context of this connector?
- Will relationship names be clear in the API?

### Scale & Blast Radius

- How many entity types does this add to the total? (Current total ~450+)
- How many ES fields will this add?
- Does this touch any shared supertypes (Asset, Catalog, SQL)?

---

## Step 3: Output

```markdown
## Design Review: <Connector/Service Name>

### Proposal Summary

<What is being proposed, in 2-3 sentences>

### Entity Model

| Type | Parent | Attributes | Relationships |
| ---- | ------ | ---------- | ------------- |
| ...  | ...    | count      | list          |

### Challenges

#### 1. <Challenge Title>

**Question:** <Specific question about the design>
**Risk if wrong:** <What happens permanently if this is the wrong call>
**Recommendation:** <What to do>

#### 2. ...

#### 3. ...

### Alternative Approaches

<At least one alternative model the team should consider>

### Verdict

- **PROCEED** — Design is sound. Build it.
- **REVISE** — Address [specific challenges] before implementing.
- **STOP** — Fundamental design issue: [description]. Needs rethink.
```

---

## Rules

- Find at least 3 genuine challenges. If you can't, the design hasn't been examined deeply enough.
- Every challenge must explain what goes permanently wrong if the design is incorrect.
- Propose at least one alternative approach, even if the original is good — it forces the team to justify their choice.
- Check existing typedefs for overlap before approving any new types.
- Think about the connector 2 years from now with 10x more features — does the model accommodate growth?

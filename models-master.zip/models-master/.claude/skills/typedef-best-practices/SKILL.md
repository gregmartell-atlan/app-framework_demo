---
description: Typedef best practices, review guidelines, and CI validation rules for the Atlan Models repository
---

# Typedef Best Practices

## Cardinal Rules

### 1. Immutability (most important)

Once a typedef is merged to `master` and deployed, it is **permanent**. There is no rollback. Mistakes cannot be undone — deleted attributes leave orphaned data, renamed types break existing queries, and changed cardinality corrupts existing relationships. Every change merged to master is a one-way door.

Review consequence: Any attribute addition, type creation, or relationship change must be treated as if it will exist forever in every Atlan tenant.

### 2. Pkl Toolkit Required

Pure JSON PRs are rejected without review. All type definitions must be authored in Pkl and committed to `typedefs/`. The JSON under `atlas/` is generated output — never edit it by hand.

### 3. Regenerate JSON and Lint Before Pushing

Use the `/regenerate-typedefs` skill to regenerate JSON from Pkl source and lint the output before opening a PR. Alternatively:

```bash
pkl eval typedefs/*.pkl -m .
npx pretty-quick
```

The CI JSON sync check will fail if generated JSON does not match the committed Pkl source.

---

## CI Validation Rules

The following checks run on every PR. Understand them to avoid CI failures.

### Hard Constraints (`validate-pkl.sh`)

Checked by the `pkl-validation` CI step. These are blocking failures:

- **PascalCase type names**: All type names in `customAssetTypes`, `customEnumTypes`, `customStructTypes`, and `customRelationshipTypes` must be PascalCase.
- **camelCase attribute names**: All attribute names must be camelCase. No underscores, no ALL_CAPS.
- **Pkl compilation**: Every `.pkl` file in `typedefs/` must compile cleanly with `pkl eval`. Syntax errors and invalid references fail here.
- **`sourceModule` is auto-set by the toolkit**: Do NOT manually set `sourceModule = thisModule` — the toolkit handles this automatically. Adding it manually is unnecessary and misleading.

Fix: Run `pkl eval typedefs/MyType.pkl` locally before pushing.

### Soft Validation (`Validator.pkl`)

Checked by the `soft-validation` CI step. These are warnings that become blocking failures after a grace period:

- **Description capitalization**: All descriptions must start with a capital letter and end with a period.
- **Plural names for multi-valued attributes**: Attributes with cardinality `SET` or `LIST` must have plural names (e.g., `tables`, not `table`).
- **Non-empty descriptions**: Every type and attribute must have a non-empty description.

### Version Check (`check-type-versions.sh`)

Checked by the `version-check` CI step:

- **New types start at `1.0`**: Any `CustomAssetType` or `CustomEnumType` without a prior version in `atlas/` must declare `version = "1.0"`.
- **Existing types bump on attribute changes**: Adding, removing, or changing attributes requires incrementing `version` (e.g., `"1.0"` → `"1.1"`). Forgetting this is the most common CI failure.

Fix: Grep for `version` in the relevant `.pkl` file and increment the patch version.

### Attribute Conflict Check (`check-attribute-conflicts.sh`)

Checked by the `conflict-check` CI step:

- **No duplicate attribute names within a type**: Including inherited attributes from the supertype chain.
- **No type conflicts across the hierarchy**: An attribute named `foo` that is `string` in a parent cannot be `int` in a child.
- **No `draftIteration` in production types**: The `draftIteration` attribute is reserved for WIP types. It must be removed before a type is considered GA.

Fix: Search the full supertype chain for the conflicting attribute name.

### Legacy Construct Check (`check-legacy-constructs.sh`)

Checked by the `legacy-check` CI step:

- **No net-new `LegacyRelationship`**: New relationships must use `ContainmentRelationship` or `PeerToPeerRelationship`. Existing `LegacyRelationship` entries are grandfathered; adding new ones fails CI.
- **No net-new `LegacyAttributeDef`**: New attributes must use the standard `AttributeDef`. `LegacyAttributeDef` exists solely for backwards-compatibility with attributes that were deployed before the toolkit introduced `attrPrefix` auto-prefixing. When the CI check flags a `LegacyAttributeDef`, that is **never a false positive** — it is always correct. The fix is to replace it with a normal attribute definition.
- **No string-based superTypes**: Use typed `superTypes { Parent.supertypeDefinition }`, not string literals.

Fix: Replace `LegacyRelationship` with `ContainmentRelationship` (for parent-child) or `PeerToPeerRelationship` (for peer associations). Replace `LegacyAttributeDef` with a standard attribute definition. See CLAUDE.md for syntax.

### JSON Sync Check

Checked by comparing committed JSON against freshly generated JSON:

- The JSON files under `atlas/` must exactly match what `pkl eval typedefs/*.pkl -m .` produces.
- Any manual edits to JSON, or forgetting to run `/regenerate-typedefs`, will fail this check.

Fix: Run `/regenerate-typedefs` and commit the updated JSON.

---

## Design Rules (Human Review Checklist)

These are not enforced by CI but are checked in human review.

### Reuse Existing Types

Before creating a new type, check whether an existing SQL, BI, or Catalog type covers the use case. Parallel hierarchies that duplicate existing semantics will be rejected. Check `typedefs/SQL.pkl`, `typedefs/BI.pkl`, `typedefs/Catalog.pkl`, and their submodules.

### Related Types Belong in the Same Pkl File

Do not create four separate Pkl files for four related types. Group logically related types in a single file (e.g., `typedefs/MyConnector.pkl` for `MyConnectorServer`, `MyConnectorDatabase`, `MyConnectorSchema`, `MyConnectorTable`). One file per logical connector or domain.

### Shared Attributes Belong in Supertypes

If two or more sibling types share the same attribute, it belongs in their common supertype, not duplicated in each leaf type. Introduce a new intermediate supertype if needed.

### Namespace Naming: Explicit and Unambiguous

Type names must be globally unambiguous across all Atlan typedefs. Use the full connector or domain name:

- `AtlanApp` not `App`
- `SnowflakeStream` not `Stream`
- `PowerBIReport` not `Report`

The namespace prefix is enforced by the toolkit's `getTypeName()` function — always use it instead of string literals.

### Auto-Prefixing: Do Not Manually Prefix Attributes

The toolkit automatically prefixes attribute names with the module's `attrPrefix`. Do not add the prefix manually in attribute key names. The key `["snowflakeRecencyInDays"]` in `Snowflake.pkl` is correct; `["snowflakeSnowflakeRecencyInDays"]` is a double-prefix bug.

Do not use `LegacyAttributeDef` to avoid the prefix. `LegacyAttributeDef` bypasses auto-prefixing by design — that is precisely what makes it wrong for new attributes. Attribute names **must always be prefixed**, and the toolkit handles this automatically. If the auto-prefixed name feels awkward, the fix is to choose a better attribute key, not to reach for `LegacyAttributeDef`.

### Never Set `isIndexable = true`

`isIndexable = true` controls whether an attribute is indexed in Cassandra. Cassandra indexing is **completely unused** in the Atlan platform — setting this flag adds permanent, irremovable bloat to every tenant and provides zero benefit.

`isIndexable` has **no bearing whatsoever on IndexSearch**, which is backed by Elasticsearch. Elasticsearch indexing is governed by the `indexType` field (e.g., `"STRING"`, `"TEXT"`, `"RELATION"`). Do not set `isIndexable = true` on any new attribute.

### Use Typed Relationships Only

New relationships must use strongly-typed endpoint references:

```pkl
// Correct
parent {
  type = SQL.getType(Schema)
  attribute = "modelSchema"
}

// Wrong - string-based, no validation
endDef1 {
  type = "Schema"   // string literal
}
```

See CLAUDE.md for `ContainmentRelationship` and `PeerToPeerRelationship` syntax.

### Draft Lifecycle: `draftIteration` for WIP

While iterating on a type that has not yet been deployed to any tenant, use `draftIteration = true` to signal that the type is not yet GA. Remove `draftIteration` before the type is considered stable and before merging to `master` for production deployment.

### No `alpha_` Prefix Hacks

Do not use `alpha_` or `_draft` or similar prefixes to "hide" attributes. Attributes are permanent once deployed — a prefixed attribute is just a permanent attribute with an ugly name. Use `draftIteration` instead for WIP.

### Elasticsearch Field Limit Awareness

Each Atlan type hierarchy contributes to the total Elasticsearch field count. Adding more than ~20 new attributes to a widely-inherited supertype (like `Asset` or `Catalog`) can push tenants over ES field limits. Flag large attribute additions in the PR for infra review.

---

## Common Mistakes and Fixes

| Mistake                                           | Symptom                                            | Fix                                                                                           |
| ------------------------------------------------- | -------------------------------------------------- | --------------------------------------------------------------------------------------------- |
| Version not incremented                           | `version-check` CI failure                         | Bump `version` in the affected type                                                           |
| Legacy construct detected                         | `legacy-check` CI failure                          | Replace `LegacyRelationship` with `ContainmentRelationship` or `PeerToPeerRelationship`       |
| JSON out of sync                                  | `json-sync` CI failure                             | Run `/regenerate-typedefs` (or `pkl eval typedefs/*.pkl -m . && npx pretty-quick`) and commit |
| Attribute name conflict                           | `conflict-check` CI failure                        | Rename the attribute or choose a different prefix                                             |
| Description casing                                | `soft-validation` warning                          | Start with capital, end with period                                                           |
| Type name not namespaced                          | Collision risk; review rejection                   | Use `getTypeName("MyType")` instead of string literals                                        |
| Manual JSON edit                                  | JSON diverges from Pkl source                      | Delete manual edit; edit the `.pkl` source and regenerate                                     |
| Double-prefix on attribute                        | Ugly permanent attribute name                      | Remove manual prefix; let the toolkit apply `attrPrefix`                                      |
| `LegacyAttributeDef` used for a new attribute     | `legacy-check` CI failure (never a false positive) | Replace with a standard attribute definition; auto-prefixing is required and correct          |
| `isIndexable = true` set on an attribute          | Silent permanent bloat; no search benefit          | Remove it entirely; use `indexType` to control Elasticsearch indexing                         |
| `draftIteration` left in                          | `conflict-check` CI failure                        | Remove `draftIteration` before GA                                                             |
| Attribute added to supertype without version bump | Silent data issue + CI failure                     | Bump the version of the supertype being modified                                              |
| Four files for four related types                 | Review rejection                                   | Consolidate into one `.pkl` file                                                              |

---

## Process Rules

### Before Opening a PR

1. **Write Pkl, not JSON.** Pure JSON PRs are rejected without review.
2. **Regenerate JSON and lint**: Run `/regenerate-typedefs` or `pkl eval typedefs/*.pkl -m . && npx pretty-quick`.
3. **Test on an isolated tenant**: Seed the typedef changes into a test tenant and verify the types load correctly and behave as expected. Do not merge to `master` without tenant validation.
4. For complex hierarchy changes, write a Technical Requirements Document (TRD) and share on `#collab-models` before implementation.

### Branch and Release Flow

The release flow for typedefs is strictly linear:

```
feature branch (from master) -> test on isolated tenant -> PR to master
```

There is **no beta or staging branch**. There are no intermediate environments in the typedef release process. Once a PR merges to `master`, it is queued for deployment to all tenants on their next upgrade cycle.

### During Review

- Post the PR link to `#collab-models`.
- CI must pass before requesting review.
- Do not force-push after a reviewer has looked at the PR — this invalidates their review context.
- Address all Critical and Warning findings before requesting re-review.

### After Merge

Changes merged to `master` are permanent. There is no rollback path. If a mistake is discovered post-merge, the only remediation is a follow-up PR that adds new attributes or types — existing ones cannot be removed or changed.

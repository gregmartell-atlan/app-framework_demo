---
description: Structured code review for pull requests with confidence scoring and inline comments
allowed-tools: Read, Grep, Glob, Bash(gh pr diff:*), Bash(gh pr view:*), Bash(gh api:*), Bash(git log:*), Bash(git diff:*), Bash(git show:*), Bash(git blame:*), Bash(gh pr comment:*), mcp__github_inline_comment__create_inline_comment
---

You are a senior code reviewer for the Atlan Models repository (Apache Atlas type definitions). Perform a structured, high-signal code review of the current pull request. No emojis. Professional tone. Only flag issues you are confident about.

## Step 1: Load repository context

Read the following files to understand the project's standards and structure. These are your evaluation criteria — do not review without them:

- `CLAUDE.md` (comprehensive guide to Pkl-based type definitions)
- `.claude/skills/typedef-best-practices/SKILL.md` (best practices and review rules: CI validation, design rules, common mistakes, process)
- `README.md` (project overview)
- `PklProject` (Pkl project configuration)
- Sample type definitions in `typedefs/` for patterns

Also look for:

- Type hierarchy documentation in CLAUDE.md
- Generation scripts and tooling patterns
- Documentation on type evolution and compatibility

## Step 2: Gather PR data

Run these commands in parallel:

- `gh pr view --json number,title,body,state,isDraft,baseRefName,headRefName,additions,deletions,changedFiles,commits,labels`
- `gh pr diff --name-only` (list of changed files)
- `gh pr diff` (full unified diff)
- `git log --oneline -30 $(gh pr view --json baseRefName -q .baseRefName)..HEAD` (branch commit history)

## Step 3: Determine review scale

Count the number of changed files from step 2.

**If fewer than 100 files changed:**
Review all changed files directly. Read each changed file using the Read tool to understand surrounding context beyond the diff. Cache these file contents for reuse in later validation steps.

**If 100 or more files changed:**
This is a large PR. Deploy parallel sub-agents to gather context efficiently:

1. Partition changed files by directory (e.g. `atlas/typedefs/`, `atlas/classificationDefs/`, `atlas/enumDefs/`, `docs/`)
2. Launch one Explore agent per partition to read the changed files and their surrounding context
3. Consolidate findings from all agents before proceeding to review passes

## Step 4: Four review passes

Execute four independent review passes **in parallel** using separate tool calls. Each pass operates independently on the file context gathered in Step 3.

### Pass 1 + 2: Pkl type definition standards

Audit the changes against the CI Validation Rules and Design Rules in `.claude/skills/typedef-best-practices/SKILL.md`. Key areas:

- **Cardinal rules**: Immutability implications, Pkl toolkit required (no raw JSON)
- **CI hard constraints**: PascalCase types, camelCase attributes, `sourceModule` on all types, Pkl compilation
- **CI soft validation**: Description capitalization and period, plural names for multi-valued attributes
- **CI version check**: New types at `1.0`, existing types bump version on attribute changes, `Asset.pkl` `typeVersion` bump
- **CI conflict check**: No duplicate attributes in hierarchy, no type conflicts, no `draftIteration` in GA types
- **CI legacy check**: No net-new `LegacyRelationship`; use `ContainmentRelationship` or `PeerToPeerRelationship`
- **Design rules**: Reuse existing types, consolidate related types in one file, shared attributes in supertypes, namespaced type names, no manual attribute prefix, typed relationship endpoints only

For each violation, reference the specific section in CLAUDE.md or `.claude/skills/typedef-best-practices/SKILL.md` being broken.

### Pass 3: Type definition correctness scan

Focus only on the diff — do not flag pre-existing issues. Check:

- **Type References**: Invalid type references, missing imports, circular dependencies
- **Hierarchy Violations**: Incorrect supertype chains, orphaned types
- **Attribute Issues**: Missing required fields, incorrect types, invalid defaults
- **Relationship Issues**: Invalid cardinality, missing end definitions, incorrect type references
- **Breaking Changes**: Removed attributes, changed types, removed relationships
  - These break backward compatibility
- **Pkl Syntax**: Proper Pkl syntax, correct use of Pkl features
  - Proper use of `local`, `amends`, `import`
  - Correct property syntax
- **JSON Generation**: Ensure changes will generate valid JSON
  - No duplicate attribute names
  - Valid JSON types
- **Documentation Gaps**: Missing descriptions on new types/attributes

Only flag significant issues. Ignore nitpicks and anything you cannot validate from the diff alone.

### Pass 4: Context and history analysis

Use git blame and git log on the changed files to understand:

- Is this adding new types, modifying existing types, or fixing issues?
- Does the change follow existing patterns in the codebase?
- Are there related types that should also be updated?
- Is the change backward compatible with existing deployments?
- Are there test fixtures or samples that need updating?
- Does documentation need updates?

## Step 5: Score and validate findings

For each issue found across all passes, assign a confidence score from 0 to 100:

- **0**: Not confident, likely false positive
- **25**: Somewhat confident, might be real
- **50**: Moderately confident, real but minor
- **75**: Highly confident, real and important
- **100**: Absolutely certain, definitely real

**Filter**: Discard all findings below confidence 80.

**Validation**: For each finding scored **80 or above**, verify it by:

- Re-reading the relevant code in full context (not just the diff) if not already cached from Step 3
- Checking if the pattern is intentionally used elsewhere in the codebase
- For CLAUDE.md violations: confirming the rule applies to this type's context

**Always discard (false positives):**

- Pre-existing issues not introduced in this PR
- Type definitions that appear incorrect but are actually correct in context
- Pedantic nitpicks a senior engineer would not flag
- General style concerns not explicitly required in CLAUDE.md
- Issues in generated files (focus on .pkl sources)

## Step 6: Post summary comment

Use `gh pr comment` to post a single comment with this exact structure. Use a HEREDOC for the body. Do not use emojis anywhere.

````
## Code Review

<2-3 sentence summary of what this PR does and its approach. Be specific about the types being added/modified.>

### Confidence Score: X/5

- <Bullet explaining what the score means for this specific PR>
- <Bullet listing what was checked: type hierarchy, attributes, relationships, backward compatibility>
- <If points were deducted, explain specifically why>

<details>
<summary>Important Files Changed</summary>

| File | Change | Risk |
|------|--------|------|
| <path> | Added/Modified/Deleted | Low/Medium/High |

</details>

### Change Flow

```mermaid
classDiagram
    class ParentType
    class NewType
    ParentType <|-- NewType
    NewType : +attribute1
    NewType : +attribute2
```

<Generate a Mermaid class diagram **if the change affects type hierarchy or adds significant new types**. Skip for simple attribute additions or documentation changes. Rules:>
<- Show type hierarchy relationships>
<- Include key attributes and relationships>
<- Maximum 10 classes in diagram>
<- For attribute changes: show before/after with annotations>

<If skipping the diagram, replace this section with a brief explanation of why it's not needed.>

### Findings

<If findings exist above threshold:>

| #   | Severity              | File                   | Issue             |
| --- | --------------------- | ---------------------- | ----------------- |
| 1   | Critical/Warning/Info | `path/to/Type.pkl:L42` | Brief description |

<If no findings:>

No issues found. Checked for type hierarchy, attribute definitions, relationships, and backward compatibility.

````

**Confidence Score Rubric:**

- **5/5**: Safe to merge — no issues, follows all standards, backward compatible
- **4/5**: Minor observations only — style/documentation nits, no functional risk
- **3/5**: Needs attention — moderate issues that should be addressed before merge
- **2/5**: Significant concerns — hierarchy violations, breaking changes, or correctness issues found
- **1/5**: Do not merge — critical problems requiring substantial rework

## Step 7: Post inline comments

For each finding in the Findings table, post an inline comment using `mcp__github_inline_comment__create_inline_comment`.

Rules for inline comments:

- Maximum 10 inline comments total (prioritize by severity), **unless there are more than 10 Critical severity findings**
- Each comment includes: severity tag, issue description, why it matters (reference CLAUDE.md), and the suggested fix
- For small, self-contained fixes (< 6 lines): include a committable suggestion block
- For larger fixes: describe the issue and suggested approach without a suggestion block
- Never post a committable suggestion unless committing it fully fixes the issue
- Post exactly ONE comment per unique issue — no duplicates
- Link format for code references: `https://github.com/<owner>/<repo>/blob/<full-sha>/path/to/file.ext#L<start>-L<end>` — always use the full SHA, never abbreviated

## Constraints

- Use `gh` CLI for all GitHub interactions. Do not use web fetch.
- Never use emojis in any output.
- Do not flag issues you cannot verify from the code. When in doubt, leave it out.
- Do not suggest changes that would require reading code outside of the changed files and their immediate context.
- Prioritize signal over completeness. A review with 3 real issues is better than one with 15 questionable ones.

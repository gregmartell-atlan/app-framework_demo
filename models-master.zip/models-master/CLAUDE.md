# Models Repository - Developer Guide

This repository uses Pkl files to define Apache Atlas type definitions. The Pkl files
serve as the single source of truth for generating JSON type definitions, code, sample
payloads, and documentation.

## Type Hierarchy System

Types form a hierarchy via typed `superTypes` references. Each `CustomAssetType` has a
`sourceModule` property that captures its defining module, enabling traversal across
Pkl definitions for code generation, documentation, and other output formats.

### Type Hierarchy Structure

```
Referenceable (root - supertypeDefinition.superTypes {})
  -> Asset
     -> Connection
     -> Cloud (AWS, Azure, Google)
     -> Catalog
        -> SQL
           -> Snowflake, BigQuery, Databricks, Dremio, etc.
        -> BI (Looker, Cognos, PowerBI, Tableau, etc.)
        -> NoSQL (Cassandra, DocumentDB, CosmosMongoDB)
```

### Adding a New Type

1. Create `typedefs/NewType.pkl`:

```pkl
amends "../toolkit/src/main/pkl/Typedefs.pkl"

import "../toolkit/src/main/pkl/Typedefs.pkl"
import "./ParentType.pkl" as Parent

local thisModule: Typedefs = this

namespace = "NewType"
modelOutputLocation = "Referenceable/Asset/Catalog/..."

supertypeDefinition {
  sourceModule = thisModule
  description = "Base class for NewType assets."
  superTypes { Parent.supertypeDefinition }  // Typed reference to parent's supertype
}

// Local type name variables for reuse
local MyAsset = getTypeName("MyAsset")

customAssetTypes {
  // Default provides sourceModule and superTypes for all entries
  default {
    sourceModule = thisModule
    superTypes { supertypeDefinition }
  }

  [MyAsset] {
    description = "Instance of MyAsset in Atlan."
    attributes {
      ["myAttribute"] {
        description = "..."
        type = "string"
      }
    }
  }
}
```

2. Run `pkl eval typedefs/NewType.pkl -m .` to verify it works

### Key Patterns

**Root types** (no parent):

```pkl
supertypeDefinition {
  sourceModule = thisModule
  superTypes {}  // Empty listing - this is the root
}
```

**Child types** (extend parent):

```pkl
superTypes { Parent.supertypeDefinition }
// or for a specific type:
superTypes { Parent.customAssetTypes[Parent.getTypeName("SomeType")] }
```

**Override default superTypes** (use `= new {}` to replace, not amend):

```pkl
customAssetTypes {
  default { sourceModule = thisModule; superTypes { supertypeDefinition } }

  [SpecialType] {
    name = SpecialType
    superTypes = new { SomeOther.customAssetTypes["OtherType"] }  // Replace default
  }
}
```

### Key Files

| File                                      | Purpose                                |
| ----------------------------------------- | -------------------------------------- |
| `toolkit/src/main/pkl/Typedefs.pkl`       | Main template that all typedefs extend |
| `toolkit/src/main/pkl/TypeHierarchy.pkl`  | Traversal utilities for type hierarchy |
| `toolkit/src/main/pkl/ModelRenderer.pkl`  | Renders typedefs to Atlas JSON         |
| `toolkit/src/main/pkl/DocsRenderer.pkl`   | Renders typedefs to docs-oriented JSON |
| `toolkit/src/main/pkl/SampleRenderer.pkl` | Generates sample JSON payloads         |
| `typedefs/*.pkl`                          | Type definitions                       |
| `atlas/entityDefs/`                       | Generated Atlas JSON output            |
| `docs/types/`                             | Generated docs JSON output             |

## Traversing the Hierarchy

Use `TypeHierarchy.pkl` utilities for traversing the type hierarchy via `sourceModule`:

```pkl
import "TypeHierarchy.pkl"

// Get all ancestor modules (parent -> grandparent -> ... -> root)
// Derived from supertypeDefinition.superTypes[0].sourceModule chain
local ancestors = TypeHierarchy.getAncestorChain(myModel)

// Get all supertype attributes including inherited (raw CustomAttributeDef)
local allAttrs = TypeHierarchy.getAllSupertypeAttributes(myModel)

// Get all resolved ancestor attributes (as Model.AttributeDef, for rendering)
// Walks the typed superTypes chain respecting legacyPayloads settings
local resolvedAttrs = TypeHierarchy.getAllResolvedAncestorAttributes(myModel)

// Get all custom asset types from the entire hierarchy
local allTypes = TypeHierarchy.getAllCustomAssetTypes(myModel)

// Get all enums from the entire hierarchy
local allEnums = TypeHierarchy.getAllEnumTypes(myModel)

// Get all structs from the entire hierarchy
local allStructs = TypeHierarchy.getAllStructTypes(myModel)

// Get namespace chain from root to current
local namespaces = TypeHierarchy.getNamespaceChain(myModel)
// e.g., ["Referenceable", "Asset", "Catalog", "SQL", "Snowflake"]

// Check if a model has a specific ancestor
local hasSqlAncestor = TypeHierarchy.hasAncestor(myModel, "SQL")
```

## Creating New Renderers

To create a new renderer for a different output format:

1. Create `toolkit/src/main/pkl/MyRenderer.pkl`
2. Import `TypeHierarchy.pkl` for traversal
3. Use `getAncestorChain()` to walk the hierarchy
4. Use `getAllResolvedAncestorAttributes()` for resolved Model.AttributeDef objects
5. Use `getAllEnumTypes()` and `getAllStructTypes()` to find types across the hierarchy

Example skeleton:

```pkl
@ModuleInfo { minPklVersion = "0.27.0" }
module com.atlan.typedef.MyRenderer

import "Typedefs.pkl"
import "TypeHierarchy.pkl"

const function render(model: Typedefs): String =
  let (ancestors = TypeHierarchy.getAncestorChain(model))
  let (allAttrs = TypeHierarchy.getAllSupertypeAttributes(model))
  // Generate your output format here
  ""
```

## Generating Output

Use the `/regenerate-typedefs` skill to regenerate all Atlas JSON, docs JSON, and lint the output in one step. See `.claude/skills/regenerate-typedefs/SKILL.md` for full usage including Python/Java SDK modes.

For a single typedef (compilation check + JSON generation):

```bash
pkl eval typedefs/Snowflake.pkl -m .
```

For samples (if `generateSamples = true`):

```bash
cd samples && ./genSamplePayloads.sh RDBMS.pkl
```

## Best Practices and Review Rules

For typedef best practices, review guidelines, common mistakes, and the CI
validation rule set, see `.claude/skills/typedef-best-practices/SKILL.md`.

## Property Reference

### Typedefs.pkl Properties

| Property                  | Type            | Description                             |
| ------------------------- | --------------- | --------------------------------------- |
| `namespace`               | String          | Type prefix (PascalCase)                |
| `attrPrefix`              | String          | Attribute prefix (camelCase)            |
| `supertypeDefinition`     | CustomAssetType | Abstract base type definition           |
| `customAssetTypes`        | Mapping         | Instantiable entity types               |
| `customEnumTypes`         | Mapping         | Enumeration definitions                 |
| `customStructTypes`       | Mapping         | Struct definitions                      |
| `customRelationshipTypes` | Mapping         | Relationship definitions                |
| `generateSamples`         | Boolean         | Enable sample payload generation        |
| `legacyPayloads`          | Boolean         | Use unprefixed names in sample payloads |

### CustomAssetType Properties

| Property       | Type                       | Description                                   |
| -------------- | -------------------------- | --------------------------------------------- |
| `sourceModule` | Typedefs (hidden)          | Module that defines this type (for hierarchy) |
| `name`         | String?                    | Type name (auto-derived from mapping key)     |
| `description`  | String                     | Type description                              |
| `superTypes`   | Listing\<CustomAssetType\> | Typed references to supertypes                |
| `attributes`   | Mapping                    | Attribute definitions                         |
| `version`      | String                     | Type version                                  |
| `passthrough`  | Boolean (hidden)           | Skip creating this type                       |

### Migration from String-based superTypes

The old string-based approach:

```pkl
// OLD - string-based, no compile-time validation
extendsFrom = Parent
supertypeDefinition {
  superTypes { "ParentType" }
}
```

The new typed approach:

```pkl
// NEW - typed references with compile-time validation
local thisModule: Typedefs = this
supertypeDefinition {
  sourceModule = thisModule
  superTypes { Parent.supertypeDefinition }
}
```

Benefits:

- Compile-time validation of type references
- IDE autocomplete and jump-to-definition
- Refactoring safety (renames propagate)
- Module relationships derived from `superTypes[0].sourceModule`

## Typed Relationship Endpoints

Relationships use strongly-typed `CustomAssetType` references via the `getType()` function.
Use local type name variables for cleaner syntax.

### Relationship Types

| Class                     | Use Case                                  |
| ------------------------- | ----------------------------------------- |
| `ContainmentRelationship` | Parent-child containment (AGGREGATION)    |
| `PeerToPeerRelationship`  | Peer-to-peer associations                 |
| `LegacyRelationship`      | Backwards-compatible string-based (avoid) |

### Syntax

**ContainmentRelationship** (parent owns children):

```pkl
import "./SQL.pkl" as SQL

local Schema = "Schema"  // Or use SQL's local variable if available
local MyModel = getTypeName("MyModel")

customRelationshipTypes {
  ["schemaAndModels"] = new ContainmentRelationship {
    parent {
      type = SQL.getType(Schema)        // Cross-module reference
      attribute = "modelSchema"
      description = "Schema containing the model."
    }
    children {
      type = module.getType(MyModel)    // Same-module reference
      attribute = "models"
      description = "Models in this schema."
    }
  }
}
```

**PeerToPeerRelationship** (bidirectional association):

```pkl
local Table = "Table"
local MyProcess = getTypeName("MyProcess")

customRelationshipTypes {
  ["tableAndProcess"] = new PeerToPeerRelationship {
    peers {
      new {
        type = SQL.getType(Table)
        attribute = "inputToProcesses"
        description = "Processes that use this table as input."
      }
      new {
        type = module.getType(MyProcess)
        attribute = "inputTables"
        description = "Tables used as input."
      }
    }
    manyToMany = true  // default
  }
}
```

### Type Reference Patterns

| Pattern                      | Description                           |
| ---------------------------- | ------------------------------------- |
| `module.getType(MyType)`     | Same-module type (using local var)    |
| `SQL.getType(Schema)`        | Cross-module type (using local var)   |
| `Parent.supertypeDefinition` | Reference parent's abstract supertype |

### LegacyRelationship (avoid for new code)

Use only for backwards-compatibility with existing string-based definitions:

```pkl
["oldRelationship"] = new LegacyRelationship {
  name = "legacy_relationship_name"
  relationshipCategory = "AGGREGATION"
  relationshipLabel = "__Parent.children"
  endDef1 {
    type = "ParentType"    // String, no compile-time validation
    attribute = "children"
    isContainer = true
    cardinality = "SET"
  }
  endDef2 {
    type = "ChildType"     // String, no compile-time validation
    attribute = "parent"
  }
}
```

## Typed Enum and Struct References

Enum and struct attributes use strongly-typed references via `getEnum()` and `getStruct()`
functions, providing compile-time validation and IDE support (similar to `getType()` for asset types).

### Lookup Functions

| Function                          | Description                |
| --------------------------------- | -------------------------- |
| `module.getEnum(EnumName)`        | Same-module enum lookup    |
| `OtherModule.getEnum("EnumName")` | Cross-module enum lookup   |
| `module.getStruct(StructName)`    | Same-module struct lookup  |
| `OtherModule.getStruct("Name")`   | Cross-module struct lookup |

### Enum References

```pkl
import "./DataQuality.pkl" as DQ

local MyStatus = getTypeName("Status")

customEnumTypes {
  [MyStatus] {
    description = "Status enum"
    validValues {
      ["ACTIVE"] { description = "Active state" }
      ["INACTIVE"] { description = "Inactive state" }
    }
  }
}

customAssetTypes {
  [MyAsset] {
    attributes {
      // Same-module typed reference
      ["status"] {
        description = "Current status"
        type = "enum"
        enum = module.getEnum(MyStatus)  // Compile-time validated
      }
      // Cross-module typed reference
      ["dqResult"] {
        description = "DQ result"
        type = "enum"
        enum = DQ.getEnum("Result")  // Compile-time validated
      }
    }
  }
}
```

### Struct References

```pkl
import "./DataQuality.pkl" as DQ

local MyConfig = getTypeName("Config")

customStructTypes {
  [MyConfig] {
    description = "Configuration struct"
    attributes {
      ["setting"] {
        description = "A setting"
        type = "string"
      }
    }
  }
}

customAssetTypes {
  [MyAsset] {
    attributes {
      // Same-module typed reference
      ["config"] {
        description = "Asset configuration"
        type = "struct"
        struct = module.getStruct(MyConfig)
      }
      // Cross-module typed reference
      ["dqConfig"] {
        description = "DQ configuration"
        type = "struct"
        struct = DQ.getStruct("RuleConfigArguments")
      }
      // Map of structs also supported
      ["configMap"] {
        description = "Map of configs"
        type = "map<string,struct>"
        struct = module.getStruct(MyConfig)
      }
    }
  }
}
```

### Benefits of Typed References

- **Compile-time validation**: Invalid references fail at Pkl evaluation time
- **IDE support**: Autocomplete and jump-to-definition for enum/struct types
- **Refactoring safety**: Renames propagate automatically
- **Cross-module clarity**: Explicit imports show dependencies

### Convenience Mappings

For cross-module access, use the `enums` and `structs` convenience mappings:

```pkl
// Access enums/structs from another module
local result = DQ.enums["Result"]      // Same as DQ.getEnum("Result")
local config = DQ.structs["Config"]    // Same as DQ.getStruct("Config")
```

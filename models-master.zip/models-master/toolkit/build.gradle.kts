/* SPDX-License-Identifier: Apache-2.0 */
plugins {
    kotlin("jvm") version "2.1.10"
    id("org.pkl-lang") version "0.28.1"
    id("java-library")
}

group = "com.atlan.typedef"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

java {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
}

dependencies {
    testImplementation(kotlin("test"))
    api("org.pkl-lang:pkl-config-kotlin:0.28.1")
}

pkl {
    kotlinCodeGenerators {
        register("genKotlin") {
            indent.set("    ")
            outputDir.set(layout.projectDirectory.dir("src/main"))
            sourceModules.add(file("src/main/pkl/Typedefs.pkl"))
            sourceModules.add(file("src/main/pkl/Frontend.pkl"))
            sourceModules.add(file("src/main/pkl/Model.pkl"))
        }
    }
    project {
        packagers {
            register("makePklPackages") {
                projectDirectories.from(file("src/main/pkl"))
            }
        }
    }
}

tasks {
    test {
        useTestNG {
            maxParallelForks = 4
            options {
                parallel = "classes"
                threadCount = 1
            }
        }
    }
    processResources {
        duplicatesStrategy = DuplicatesStrategy.INCLUDE
    }
    assemble {
        dependsOn("makePklPackages")
    }
    getByName("makePklPackages") {
        dependsOn(
            "processResources",
            "compileKotlin",
            "jar",
        )
    }
}
kotlin {
    jvmToolchain(17)
}

/* SPDX-License-Identifier: Apache-2.0 */
rootProject.name = "toolkit"

pluginManagement {
    repositories {
        mavenCentral()
    }
}
/* SPDX-License-Identifier: Apache-2.0
   Copyright 2023 Atlan Pte. Ltd. */
import com.atlan.typedef.Model
import com.atlan.typedef.Typedefs
import org.pkl.config.java.ConfigEvaluator
import org.pkl.config.kotlin.forKotlin
import org.pkl.config.kotlin.to
import org.pkl.core.ModuleSource
import org.testng.annotations.BeforeClass
import org.testng.annotations.Test
import kotlin.test.assertEquals
import kotlin.test.assertFalse
import kotlin.test.assertNotNull
import kotlin.test.assertTrue

object CanonicalExampleTest {
    lateinit var model: Typedefs

    @BeforeClass
    fun modelEval() {
        val source = ModuleSource.path("src/test/resources/CanonicalExample.pkl")
        model =
            ConfigEvaluator.preconfigured().forKotlin().use { evaluator ->
                evaluator.evaluate(source).to<Typedefs>()
            }
    }

    @Test
    fun testModelBasics() {
        assertNotNull(model)
        assertNotNull(model.namespace)
        assertNotNull(model.attrPrefix)
        assertEquals("Custom", model.namespace)
        assertEquals("custom", model.attrPrefix)
    }

    @Test
    fun testSupertype() {
        assertNotNull(model.supertypeDefinition)
        assertEquals("Custom", model.supertypeDefinition.name)
        assertEquals("Base class for all Custom types.", model.supertypeDefinition.description)
        assertNotNull(model.supertypeDefinition.superTypes)
        assertEquals(1, model.supertypeDefinition.superTypes?.size)
        assertEquals("Catalog", model.supertypeDefinition.superTypes?.get(0))
        assertNotNull(model.supertypeDefinition.attributes)
        assertEquals(
            3,
            model.supertypeDefinition.attributes!!
                .size,
        )
        assertEquals(
            "Unique identifier for the Custom asset from the source system.",
            model.supertypeDefinition.attributes!!["sourceId"]?.description,
        )
        assertEquals(
            "string",
            model.supertypeDefinition.attributes!!["sourceId"]?.typeName,
        )
        assertEquals(
            "Simple name of the dataset in which this asset exists, or empty if it is itself a dataset.",
            model.supertypeDefinition.attributes!!["datasetName"]?.description,
        )
        assertEquals(
            "string",
            model.supertypeDefinition.attributes!!["datasetName"]?.typeName,
        )
        assertEquals(
            "Unique name of the dataset in which this asset exists, or empty if it is itself a dataset.",
            model.supertypeDefinition.attributes!!["datasetQualifiedName"]?.description,
        )
        assertEquals(
            "string",
            model.supertypeDefinition.attributes!!["datasetQualifiedName"]?.typeName,
        )
    }

    @Test
    fun testCustomTypes() {
        assertNotNull(model.customAssetTypes)
        assertEquals(3, model.customAssetTypes.size)
        assertEquals(3, model.customEntityDefs!!.size)
    }

    @Test
    fun testDatasetType() {
        val dataset = model.customEntityDefs!![0]
        assertNotNull(dataset)
        assertEquals("CustomDataset", dataset.name)
        assertEquals("Instances of CustomDataset in Atlan.", dataset.description)
        assertEquals(1, dataset.superTypes.size)
        assertEquals("Custom", dataset.superTypes[0])
        assertTrue(dataset.attributeDefs!!.isEmpty())
    }

    @Test
    fun testTableType() {
        val table = model.customEntityDefs!![1]
        assertNotNull(table)
        assertEquals("CustomTable", table.name)
        assertEquals("Instances of CustomTable in Atlan.", table.description)
        assertEquals(2, table.superTypes.size)
        assertEquals("Custom", table.superTypes[0])
        assertEquals("Table", table.superTypes[1])
        assertEquals(1, table.attributeDefs!!.size)
        assertEquals("customRatings", table.attributeDefs!![0].name)
        assertEquals("Ratings for the CustomTable asset from the source system.", table.attributeDefs!![0].description)
        assertEquals("array<CustomRatings>", table.attributeDefs!![0].typeName)
    }

    @Test
    fun testCustomStructs() {
        assertNotNull(model.customStructTypes)
        assertEquals(1, model.customStructTypes!!.size)
    }

    @Test
    fun testTableStruct() {
        val ratings = model.customStructTypes!!["CustomRatings"]
        assertNotNull(ratings)
        // assertEquals("CustomRatings", ratings.name)
        assertEquals("Ratings for an asset from the source system.", ratings.description)
        assertEquals(2, ratings.attributes!!.size)
        assertEquals("Username of the user who left the rating.", ratings.attributes!!["ratingFrom"]?.description)
        assertEquals("string", ratings.attributes!!["ratingFrom"]?.typeName)
        assertEquals("Numeric score for the rating left by the user.", ratings.attributes!!["ratingOf"]?.description)
        assertEquals("long", ratings.attributes!!["ratingOf"]?.typeName)
    }

    @Test
    fun testFieldType() {
        val field = model.customEntityDefs!![2]
        assertNotNull(field)
        assertEquals("CustomField", field.name)
        assertEquals("Instances of CustomField in Atlan.", field.description)
        assertEquals(2, field.superTypes.size)
        assertEquals("Custom", field.superTypes[0])
        assertEquals("Column", field.superTypes[1])
        assertEquals(1, field.attributeDefs!!.size)
        assertEquals("customTemperature", field.attributeDefs!![0].name)
        assertEquals("Temperature of the CustomField asset.", field.attributeDefs!![0].description)
        assertEquals("CustomTemperatureType", field.attributeDefs!![0].typeName)
    }

    @Test
    fun testCustomEnums() {
        assertNotNull(model.customEnumTypes)
        assertEquals(1, model.customEnumTypes!!.size)
    }

    @Test
    fun testFieldEnum() {
        val enum = model.customEnumTypes!!["CustomTemperatureType"]
        assertNotNull(enum)
        // assertEquals("CustomTemperatureType", enum.name)
        assertEquals("Valid values for CustomTable temperatures.", enum.description)
        assertEquals(2, enum.validValues.size)
        assertEquals(setOf("HOT", "COLD"), enum.validValues.keys.toSet())
        assertEquals("Lowest availability, can be offline storage.", enum.validValues["COLD"]?.description)
        assertEquals("Highest availability, must be on solid-state or in-memory storage.", enum.validValues["HOT"]?.description)
    }

    @Test
    fun testCustomRelationships() {
        assertNotNull(model.customRelationshipDefs)
        assertEquals(3, model.customRelationshipDefs!!.size)
    }

    @Test
    fun testFieldRelationship() {
        val r1 = model.customRelationshipDefs!![0]
        assertNotNull(r1)
        assertEquals("custom_dataset_custom_tables", r1.name)
        assertEquals("Containment relationship between CustomDataset and CustomTable.", r1.description)
        assertEquals("CustomDataset", r1.endDef1.type)
        assertEquals("CustomTable", r1.endDef2.type)
        assertEquals("customTables", r1.endDef1.name)
        assertEquals("customDataset", r1.endDef2.name)
        assertEquals("Tables contained within the Dataset.", r1.endDef1.description)
        assertEquals("Dataset containing the Table.", r1.endDef2.description)
        assertTrue(r1.endDef1.isContainer)
        assertFalse(r1.endDef2.isContainer)
        assertEquals(Model.Cardinality.SET, r1.endDef1.cardinality)
        assertEquals(Model.Cardinality.SINGLE, r1.endDef2.cardinality)
        assertEquals(Model.PropagationType.NONE, r1.propagateTags)

        val r2 = model.customRelationshipDefs!![1]
        assertNotNull(r2)
        assertEquals("custom_table_custom_fields", r2.name)
        assertEquals("Containment relationship between CustomTable and CustomField.", r2.description)
        assertEquals("CustomTable", r2.endDef1.type)
        assertEquals("CustomField", r2.endDef2.type)
        assertEquals("customFields", r2.endDef1.name)
        assertEquals("customTable", r2.endDef2.name)
        assertEquals("Fields contained within the Table.", r2.endDef1.description)
        assertEquals("Table containing the Field.", r2.endDef2.description)
        assertTrue(r2.endDef1.isContainer)
        assertFalse(r2.endDef2.isContainer)
        assertEquals(Model.Cardinality.SET, r2.endDef1.cardinality)
        assertEquals(Model.Cardinality.SINGLE, r2.endDef2.cardinality)
        assertEquals(Model.PropagationType.NONE, r2.propagateTags)

        val r3 = model.customRelationshipDefs!![2]
        assertNotNull(r3)
        assertEquals("custom_from_fields_custom_to_fields", r3.name)
        assertEquals("Many-to-many peer-to-peer relationship between CustomFields.", r3.description)
        assertEquals("CustomField", r3.endDef1.type)
        assertEquals("CustomField", r3.endDef2.type)
        assertEquals("customToFields", r3.endDef1.name)
        assertEquals("customFromFields", r3.endDef2.name)
        assertEquals("CustomFields to which this CustomField is related.", r3.endDef1.description)
        assertEquals("CustomFields from which this CustomField is related.", r3.endDef2.description)
        assertFalse(r3.endDef1.isContainer)
        assertFalse(r3.endDef2.isContainer)
        assertEquals(Model.Cardinality.SET, r3.endDef1.cardinality)
        assertEquals(Model.Cardinality.SET, r3.endDef2.cardinality)
        assertEquals(Model.PropagationType.NONE, r3.propagateTags)
    }
}

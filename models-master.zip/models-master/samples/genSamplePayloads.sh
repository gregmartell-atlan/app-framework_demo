#!/usr/bin/env bash

set -e

if [ $# -eq 0 ]; then
    echo "Usage: $0 <pkl-file>"
    exit 1
fi

INPUT_FILE="$1"

# Step 1: Generate multi-output JSON files from Pkl
echo "🚀  Generating JSON outputs from Pkl..."
pkl eval "$INPUT_FILE" -m .

# Step 2: Transform the formatted sample payload to JSON Lines format
BASE_NAME=$(basename "$INPUT_FILE" .pkl)
JSON_INPUT="payloads/${BASE_NAME}.json"
JSONL_OUTPUT="payloads/${BASE_NAME}.jsonl"

if [ ! -f "$JSON_INPUT" ]; then
    echo "Error: Expected output file $JSON_INPUT not found"
    exit 1
fi

echo "⚙️  Transforming $JSON_INPUT to JSON Lines format..."
jq -c '.entities[]' "$JSON_INPUT" > "$JSONL_OUTPUT"

echo "✅  Done! Generated $JSONL_OUTPUT"

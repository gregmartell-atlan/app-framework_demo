#!/bin/bash
# SPDX-License-Identifier: Apache-2.0
# Copyright 2025 Atlan Pte. Ltd.

# Check Type Versions Script
# Rules documented in .claude/skills/typedef-best-practices/SKILL.md
# Validates that type versions are incremented when attributes are added.
# Uses Pkl for validation logic, bash only for git operations.
#
# Usage:
#   ./scripts/check-type-versions.sh [changed_files...]
#
# If no files are provided, checks all typedefs/*.pkl files.
# Requires GITHUB_BASE_REF environment variable to be set (PR base branch).

set -e

BASE_BRANCH="${GITHUB_BASE_REF:-master}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
ERRORS=0

# Helper function to check if a file exists in base branch
file_exists_in_base() {
    local file="$1"
    git show "origin/$BASE_BRANCH:$file" >/dev/null 2>&1
}

# Process a single Pkl file
check_pkl_file() {
    local pkl_file="$1"
    local relative_path="${pkl_file#$REPO_ROOT/}"

    echo "Checking $relative_path..."

    # Check if file exists in base branch
    if ! file_exists_in_base "$relative_path"; then
        echo "  New file, checking initial versions..."

        # Create a wrapper module in repo root (so relative imports work)
        local check_file="$REPO_ROOT/.version-check-$$.pkl"
        trap "rm -f $check_file" RETURN

        cat > "$check_file" << EOF
import "toolkit/src/main/pkl/VersionChecker.pkl"
import "$relative_path" as current

errors = VersionChecker.checkVersions(current, null)

output {
  text = if (errors.isEmpty) "PASSED" else errors.join("\n")
}
EOF
        local output
        if ! output=$(cd "$REPO_ROOT" && pkl eval "$check_file" 2>&1); then
            rm -f "$check_file"
            echo "  ERROR: Failed to evaluate $relative_path"
            echo "$output"
            return 1
        fi
        rm -f "$check_file"

        if [ "$output" != "PASSED" ]; then
            echo "$output" | sed 's/^/  /'
            return 1
        fi
        echo "  OK: All versions are 1.0"
        return 0
    fi

    # Get the base branch version of the file to a temp location in typedefs/
    local base_file="$REPO_ROOT/typedefs/.base-$$.pkl"
    local check_file="$REPO_ROOT/.version-check-$$.pkl"
    trap "rm -f $base_file $check_file" RETURN

    if ! git show "origin/$BASE_BRANCH:$relative_path" > "$base_file" 2>/dev/null; then
        echo "  Could not get base version, skipping..."
        return 0
    fi

    # Create a wrapper module in repo root
    cat > "$check_file" << EOF
import "toolkit/src/main/pkl/VersionChecker.pkl"
import "$relative_path" as current
import "typedefs/.base-$$.pkl" as base

errors = VersionChecker.checkVersions(current, base)

output {
  text = if (errors.isEmpty) "PASSED" else errors.join("\n")
}
EOF

    local output
    if ! output=$(cd "$REPO_ROOT" && pkl eval "$check_file" 2>&1); then
        rm -f "$base_file" "$check_file"
        echo "  ERROR: Failed to evaluate version check"
        echo "$output" | sed 's/^/  /'
        return 1
    fi
    rm -f "$base_file" "$check_file"

    if [ "$output" != "PASSED" ]; then
        echo "$output" | sed 's/^/  /'
        return 1
    fi

    echo "  OK: All versions valid"
    return 0
}

# Main execution
main() {
    echo "Type Version Check"
    echo "Base branch: $BASE_BRANCH"
    echo ""

    # Get list of files to check
    local files=("$@")

    if [ ${#files[@]} -eq 0 ]; then
        # No files provided, check all typedefs
        while IFS= read -r -d '' file; do
            files+=("$file")
        done < <(find "$REPO_ROOT/typedefs" -name "*.pkl" -type f -print0 2>/dev/null)
    fi

    # Filter to only .pkl files in typedefs/ that exist
    local pkl_files=()
    for file in "${files[@]}"; do
        if [[ "$file" == *.pkl ]] && [[ "$file" == *typedefs/* ]]; then
            # Convert to absolute path if needed
            if [[ "$file" != /* ]]; then
                file="$REPO_ROOT/$file"
            fi
            # Skip deleted files
            if [ ! -f "$file" ]; then
                echo "Skipping deleted file: $file"
                continue
            fi
            pkl_files+=("$file")
        fi
    done

    if [ ${#pkl_files[@]} -eq 0 ]; then
        echo "No Pkl files to check."
        exit 0
    fi

    echo "Checking ${#pkl_files[@]} Pkl file(s)..."
    echo ""

    for pkl_file in "${pkl_files[@]}"; do
        if ! check_pkl_file "$pkl_file"; then
            ERRORS=$((ERRORS + 1))
        fi
    done

    echo ""
    if [ $ERRORS -gt 0 ]; then
        echo "FAILED: $ERRORS file(s) with version errors"
        exit 1
    else
        echo "PASSED: All version checks passed"
        exit 0
    fi
}

main "$@"

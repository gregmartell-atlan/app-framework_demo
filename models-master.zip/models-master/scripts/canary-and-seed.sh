#!/usr/bin/env bash
set -euo pipefail

SCRIPT_NAME="$(basename "$0")"

usage() {
  cat <<EOF
Usage: $SCRIPT_NAME [--verify-only] <tenant-name> [branch-name]

Deploy typedef changes to an isolated tenant for testing.

Options:
  --verify-only   Skip patching and workflow submission; only connect to
                  the tenant and verify that typedefs are present in Atlas.

Examples:
  # Full run: patch ConfigMap, run seeder workflow, and verify typedefs
  $SCRIPT_NAME mytenantname feat/my-new-typedefs

  # Full run using current git branch
  $SCRIPT_NAME mytenantname

  # Verify only: check if typedefs from the branch are already in Atlas
  # (useful after a workflow has already run, or to re-check without re-seeding)
  $SCRIPT_NAME --verify-only mytenantname feat/my-new-typedefs

Steps performed (full run):
  1. Switch to the tenant's vcluster
  2. Patch the atlan-runtime-packages-config ConfigMap to use the feature branch
  3. Submit the typedef-seeder Argo workflow
  4. Wait for the workflow to complete and show logs
  5. Verify new typedefs are present in Atlas metastore

Steps performed (--verify-only):
  1. Switch to the tenant's vcluster
  2. Verify new typedefs are present in Atlas metastore

Arguments:
  tenant-name   Name of the vcluster tenant to deploy to
  branch-name   Git branch to use (defaults to current branch)

Prerequisites:
  - vcluster, kubectl CLI tools installed and authenticated
  - argo CLI also required for full runs (not needed with --verify-only)
EOF
  exit 1
}

# --- Argument parsing ---
VERIFY_ONLY=false
if [[ "${1:-}" == "--verify-only" ]]; then
  VERIFY_ONLY=true
  shift
fi

if [[ $# -lt 1 ]]; then
  usage
fi

TENANT="$1"
BRANCH="${2:-$(git rev-parse --abbrev-ref HEAD)}"

echo "==> Tenant:  $TENANT"
echo "==> Branch:  $BRANCH"
echo

# --- Prerequisite checks ---
REQUIRED_CMDS=(vcluster kubectl)
if [[ "$VERIFY_ONLY" == false ]]; then
  REQUIRED_CMDS+=(argo)
fi
for cmd in "${REQUIRED_CMDS[@]}"; do
  if ! command -v "$cmd" &>/dev/null; then
    echo "ERROR: '$cmd' is not installed or not in PATH." >&2
    exit 1
  fi
done

# --- Step 1: Switch to vcluster ---
echo "==> Switching to vcluster '$TENANT' ..."
vcluster platform connect vcluster "$TENANT"
echo

if [[ "$VERIFY_ONLY" == false ]]; then
  # --- Step 2: Patch ConfigMap ---
  CONFIGMAP="atlan-runtime-packages-config"
  echo "==> Patching ConfigMap '$CONFIGMAP' to set modelsBranch=$BRANCH ..."
  kubectl patch configmap "$CONFIGMAP" \
    --type merge \
    -p "{\"data\":{\"modelsBranch\":\"$BRANCH\"}}"
  echo

  # Verify the patch
  echo "==> Verifying ConfigMap patch ..."
  ACTUAL_BRANCH=$(kubectl get configmap "$CONFIGMAP" -o jsonpath='{.data.modelsBranch}')
  if [[ "$ACTUAL_BRANCH" != "$BRANCH" ]]; then
    echo "ERROR: ConfigMap patch verification failed. Expected '$BRANCH', got '$ACTUAL_BRANCH'." >&2
    exit 1
  fi
  echo "    modelsBranch is now '$ACTUAL_BRANCH'"
  echo

  # --- Step 3: Submit Argo workflow ---
  WORKFLOW_TEMPLATE="atlan-typedef-seeder"
  echo "==> Submitting Argo workflow from ClusterWorkflowTemplate '$WORKFLOW_TEMPLATE' ..."
  WORKFLOW_NAME=$(argo submit \
    --from "clusterworkflowtemplate/$WORKFLOW_TEMPLATE" \
    --generate-name "typedef-seeder-canary-" \
    -o name)
  echo "    Workflow submitted: $WORKFLOW_NAME"
  echo

  # --- Step 4: Wait and tail logs ---
  echo "==> Waiting for workflow '$WORKFLOW_NAME' to complete (tailing logs) ..."
  echo "---"
  argo logs "$WORKFLOW_NAME" --follow || true
  echo "---"
  echo

  # --- Step 5: Verify completion ---
  echo "==> Checking workflow status ..."
  argo wait "$WORKFLOW_NAME" >/dev/null 2>&1 || true
  STATUS=$(argo get "$WORKFLOW_NAME" -o json | python3 -c "import sys,json; print(json.load(sys.stdin)['status']['phase'])")

  echo "    Workflow status: $STATUS"
  echo

  if [[ "$STATUS" != "Succeeded" ]]; then
    echo "==> WARNING: Workflow did not succeed (status: $STATUS)." >&2
    echo "    Run 'argo get $WORKFLOW_NAME' for details." >&2
    exit 1
  fi

  echo "==> Canary deployment succeeded! Typedefs from branch '$BRANCH' are now on tenant '$TENANT'."
  echo
fi

# --- Verify typedefs in Atlas ---
echo "==> Verifying typedefs in Atlas metastore ..."

# Ensure we clean up port-forwards on exit
PIDS_TO_CLEAN=()
cleanup() {
  for pid in "${PIDS_TO_CLEAN[@]}"; do
    kill "$pid" 2>/dev/null || true
  done
}
trap cleanup EXIT

# Collect expected entity type names from the branch's generated JSON files
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
ENTITY_DEFS_DIR="$REPO_ROOT/atlas/entityDefs"

if [[ ! -d "$ENTITY_DEFS_DIR" ]]; then
  echo "    WARNING: Cannot find atlas/entityDefs directory, skipping verification." >&2
  exit 0
fi

EXPECTED_TYPES=$(find "$ENTITY_DEFS_DIR" -name '*.json' ! -name '*_relationships.json' \
  -exec python3 -c "
import json, sys
for path in sys.argv[1:]:
    with open(path) as f:
        data = json.load(f)
    for e in data.get('entityDefs', []):
        print(e['name'])
" {} +  | sort -u)

EXPECTED_COUNT=$(echo "$EXPECTED_TYPES" | wc -l | tr -d ' ')
echo "    Found $EXPECTED_COUNT expected entity types from branch JSON files."

# --- Obtain OAuth2 token from Keycloak ---
echo "    Obtaining OAuth2 token ..."
KEYCLOAK_PORT=21002
kubectl port-forward svc/keycloak-http -n keycloak "$KEYCLOAK_PORT:80" &>/dev/null &
PIDS_TO_CLEAN+=($!)
sleep 3

# Read client credentials from the secret used by the typedef-seeder workflow
CLIENT_ID=$(kubectl get secret argo-client-creds -o jsonpath='{.data.login}' | base64 -d)
CLIENT_SECRET=$(kubectl get secret argo-client-creds -o jsonpath='{.data.password}' | base64 -d)

TOKEN=$(curl -sf -X POST "http://localhost:$KEYCLOAK_PORT/auth/realms/default/protocol/openid-connect/token" \
  -d "grant_type=client_credentials" \
  -d "client_id=$CLIENT_ID" \
  -d "client_secret=$CLIENT_SECRET" | python3 -c "import json,sys; print(json.load(sys.stdin)['access_token'])") || {
  echo "    WARNING: Could not obtain OAuth2 token. Skipping Atlas verification." >&2
  exit 0
}

# --- Port-forward to Atlas and query typedefs ---
ATLAS_PORT=21001
echo "    Starting port-forward to atlas-ratelimited ..."
kubectl port-forward svc/atlas-ratelimited -n atlas "$ATLAS_PORT:80" &>/dev/null &
PIDS_TO_CLEAN+=($!)
sleep 3

ATLAS_URL="http://localhost:$ATLAS_PORT/api/atlas/v2/types/typedefs?type=entity"
echo "    Querying Atlas for entity typedefs ..."

ATLAS_RESPONSE=$(curl -sf -H "Authorization: Bearer $TOKEN" "$ATLAS_URL" 2>/dev/null) || {
  echo "    WARNING: Could not reach Atlas API. Skipping verification." >&2
  exit 0
}

ATLAS_TYPES=$(echo "$ATLAS_RESPONSE" | python3 -c "
import json, sys
data = json.load(sys.stdin)
for e in data.get('entityDefs', []):
    print(e['name'])
" | sort -u)

# Compare: find expected types missing from Atlas
MISSING_TYPES=$(comm -23 <(echo "$EXPECTED_TYPES") <(echo "$ATLAS_TYPES"))

if [[ -z "$MISSING_TYPES" ]]; then
  echo
  echo "==> All $EXPECTED_COUNT entity types are present in Atlas. Verification passed!"
else
  MISSING_COUNT=$(echo "$MISSING_TYPES" | wc -l | tr -d ' ')
  echo
  echo "==> WARNING: $MISSING_COUNT entity type(s) missing from Atlas:" >&2
  echo "$MISSING_TYPES" | sed 's/^/      - /' >&2
  echo
  echo "    These types were expected from the branch JSON but not found in the metastore."
  exit 1
fi

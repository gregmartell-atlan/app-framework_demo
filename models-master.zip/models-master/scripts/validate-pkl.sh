#!/bin/bash
# SPDX-License-Identifier: Apache-2.0
# Copyright 2025 Atlan Pte. Ltd.

# Validate Pkl Files Script
# Rules documented in .claude/skills/typedef-best-practices/SKILL.md
# Runs soft validation (warnings) on Pkl typedef files.
#
# Usage:
#   ./scripts/validate-pkl.sh [pkl_files...]
#
# If no files are provided, validates all typedefs/*.pkl files.

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# Process a single Pkl file for soft validation warnings
validate_pkl_file() {
    local pkl_file="$1"
    local relative_path="${pkl_file#$REPO_ROOT/}"

    echo "Checking soft constraints in $relative_path..."

    # Create a temporary Pkl module in repo root (so relative imports work)
    local temp_module="$REPO_ROOT/.validate-tmp-$$.pkl"

    cat > "$temp_module" << EOF
import "toolkit/src/main/pkl/Validator.pkl"
import "$relative_path" as Target

result = Validator.renderWarnings(Validator.validate(Target))
EOF

    # Run validation - capture stderr separately to show actual errors
    local warnings
    local stderr_file
    stderr_file=$(mktemp)

    if ! warnings=$(pkl eval -x result "$temp_module" 2>"$stderr_file"); then
        echo "  ERROR: Failed to evaluate $relative_path"
        cat "$stderr_file" >&2
        rm -f "$temp_module" "$stderr_file"
        return 1
    fi

    rm -f "$temp_module" "$stderr_file"

    # Check if warnings is empty (pkl eval -x returns empty string or '""' for no warnings)
    if [ -n "$warnings" ] && [ "$warnings" != '""' ]; then
        # Remove surrounding quotes and print
        echo "$warnings" | sed 's/^"//;s/"$//' | sed 's/\\n/\n/g'
        return 1
    fi
    return 0
}

# Main execution
main() {
    local files=("$@")

    if [ ${#files[@]} -eq 0 ]; then
        # No files provided, validate all typedefs
        while IFS= read -r -d '' file; do
            files+=("$file")
        done < <(find "$REPO_ROOT/typedefs" -name "*.pkl" -type f -print0 2>/dev/null)
    fi

    # Filter to only .pkl files in typedefs/ that exist
    local pkl_files=()
    for file in "${files[@]}"; do
        if [[ "$file" == *.pkl ]] && [[ "$file" == *typedefs/* ]]; then
            # Convert to absolute path if needed
            if [[ "$file" != /* ]]; then
                file="$REPO_ROOT/$file"
            fi
            # Skip deleted files
            if [ ! -f "$file" ]; then
                echo "Skipping deleted file: $file"
                continue
            fi
            pkl_files+=("$file")
        fi
    done

    if [ ${#pkl_files[@]} -eq 0 ]; then
        echo "No Pkl files to validate."
        exit 0
    fi

    echo "Validating ${#pkl_files[@]} Pkl file(s) for soft constraints..."
    echo ""

    local has_warnings=false
    for pkl_file in "${pkl_files[@]}"; do
        if ! validate_pkl_file "$pkl_file"; then
            has_warnings=true
        fi
    done

    echo ""
    if [ "$has_warnings" = true ]; then
        echo "Soft validation warnings found. Please review the above warnings."
        exit 1
    else
        echo "No soft validation warnings found."
        exit 0
    fi
}

main "$@"

#!/bin/bash
# SPDX-License-Identifier: Apache-2.0
# Copyright 2025 Atlan Pte. Ltd.

# Check Attribute Conflicts Script
# Rules documented in .claude/skills/typedef-best-practices/SKILL.md
# Validates that there are no conflicting attribute or type names across typedef files.
#
# Usage:
#   ./scripts/check-attribute-conflicts.sh

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

echo "Cross-File Attribute Conflict Check"
echo ""

# Run the Pkl conflict checker
cd "$REPO_ROOT"
output=$(pkl eval toolkit/src/main/pkl/ConflictChecker.pkl 2>&1)

echo "$output"

# Check if there were any errors
if echo "$output" | grep -q "^PASSED:"; then
    exit 0
else
    exit 1
fi

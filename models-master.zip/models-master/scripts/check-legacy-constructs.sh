#!/bin/bash
# SPDX-License-Identifier: Apache-2.0
# Copyright 2025 Atlan Pte. Ltd.

# Check Legacy Constructs Script
# Rules documented in .claude/skills/typedef-best-practices/SKILL.md
# Detects when PRs add new lines containing legacy constructs.
# Only added/changed lines are flagged - existing unchanged content is allowed.
#
# Usage:
#   ./scripts/check-legacy-constructs.sh [changed_files...]
#
# If no files are provided, checks all typedefs/*.pkl files.
# Requires GITHUB_BASE_REF environment variable to be set (PR base branch).
#
# Exit codes:
#   0 - Pass (no errors, warnings may be present)
#   1 - Fail (errors found)

set -e

BASE_BRANCH="${GITHUB_BASE_REF:-master}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

ERRORS=0
WARNINGS=0

# Legacy constructs to detect
# Format: "pattern~severity~alternative"
LEGACY_PATTERNS=(
    'new LegacyAttributeDef~error~{'
    'new LegacyRelationshipAttributeDef~error~{'
    'new LegacyRelationship([^A-Za-z]|$)~error~ContainmentRelationship or PeerToPeerRelationship'
    'new LegacyRelationshipEndDef~error~Typed relationship endpoints'
    'legacyAssetTypes \{~error~customAssetTypes'
    'legacyEnumTypes \{~error~customEnumTypes'
    'legacyStructTypes \{~error~customStructTypes'
)

# Check if a file exists in base branch
file_exists_in_base() {
    local file="$1"
    git show "origin/$BASE_BRANCH:$file" >/dev/null 2>&1
}

# Check a single file for legacy constructs in added lines
check_file() {
    local file="$1"
    local relative_path="${file#$REPO_ROOT/}"

    # Make sure we have an absolute path for the file check
    if [[ "$file" != /* ]]; then
        file="$REPO_ROOT/$file"
        relative_path="$1"
    fi

    # Skip deleted files
    if [ ! -f "$file" ]; then
        return 0
    fi

    local file_errors=0
    local file_warnings=0

    # Get the diff for this file
    local diff_output
    if file_exists_in_base "$relative_path"; then
        # Existing file - get diff of changes
        diff_output=$(git diff "origin/$BASE_BRANCH...HEAD" --unified=0 -- "$relative_path" 2>/dev/null || true)
    else
        # New file - treat entire file as added
        # Create a pseudo-diff where all lines are additions
        diff_output=$(awk '{print "+" $0}' "$file")
        # Add a fake hunk header so line tracking works
        diff_output="@@ -0,0 +1,$(wc -l < "$file" | tr -d ' ') @@"$'\n'"$diff_output"
    fi

    if [ -z "$diff_output" ]; then
        return 0
    fi

    # Process the diff to find added lines with their line numbers
    local current_line=0
    local in_hunk=false

    while IFS= read -r line; do
        # Check for hunk header: @@ -old,count +new,count @@
        if [[ "$line" =~ ^@@[[:space:]]+-[0-9]+(,[0-9]+)?[[:space:]]+\+([0-9]+)(,[0-9]+)?[[:space:]]+@@ ]]; then
            current_line="${BASH_REMATCH[2]}"
            current_line=$((current_line - 1)) # Will be incremented on first line
            in_hunk=true
            continue
        fi

        # Skip if not in a hunk yet
        if [ "$in_hunk" = false ]; then
            continue
        fi

        # Track line numbers
        if [[ "$line" =~ ^\+ ]] && [[ ! "$line" =~ ^\+\+\+ ]]; then
            # This is an added line
            current_line=$((current_line + 1))
            local content="${line:1}" # Remove the leading +

            # Check against each legacy pattern
            for pattern_entry in "${LEGACY_PATTERNS[@]}"; do
                IFS='~' read -r pattern severity alternative <<< "$pattern_entry"

                if echo "$content" | grep -qE "$pattern"; then
                    if [ "$severity" = "error" ]; then
                        echo "ERROR: $relative_path:$current_line"
                        echo "  Found: $pattern"
                        echo "  Use instead: $alternative"
                        echo ""
                        file_errors=$((file_errors + 1))
                    else
                        echo "WARNING: $relative_path:$current_line"
                        echo "  Found: $pattern"
                        echo "  Consider: $alternative"
                        echo ""
                        file_warnings=$((file_warnings + 1))
                    fi
                fi
            done
        fi
        # With --unified=0 there are no context lines; deletions don't increment

    done <<< "$diff_output"

    ERRORS=$((ERRORS + file_errors))
    WARNINGS=$((WARNINGS + file_warnings))

    return 0
}

# Main execution
main() {
    echo "Legacy Construct Check"
    echo "Base branch: $BASE_BRANCH"
    echo ""

    # Get list of files to check
    local files=("$@")

    if [ ${#files[@]} -eq 0 ]; then
        # No files provided, check all typedefs
        while IFS= read -r -d '' file; do
            files+=("$file")
        done < <(find "$REPO_ROOT/typedefs" -name "*.pkl" -type f -print0 2>/dev/null)
    fi

    # Filter to only .pkl files in typedefs/
    local pkl_files=()
    for file in "${files[@]}"; do
        if [[ "$file" == *.pkl ]] && [[ "$file" == *typedefs/* ]]; then
            pkl_files+=("$file")
        fi
    done

    if [ ${#pkl_files[@]} -eq 0 ]; then
        echo "No Pkl files to check."
        exit 0
    fi

    echo "Checking ${#pkl_files[@]} Pkl file(s) for legacy constructs..."
    echo ""

    for pkl_file in "${pkl_files[@]}"; do
        check_file "$pkl_file"
    done

    # Summary
    echo "----------------------------------------"
    if [ $ERRORS -gt 0 ] || [ $WARNINGS -gt 0 ]; then
        echo "Summary: $ERRORS error(s), $WARNINGS warning(s)"
        echo ""
        if [ $ERRORS -gt 0 ]; then
            echo "FAILED: Legacy constructs detected in added lines."
            echo ""
            echo "Please use modern typed constructs instead of legacy ones."
            echo "See CLAUDE.md for migration guidance."
            exit 1
        else
            echo "PASSED with warnings."
            exit 0
        fi
    else
        echo "PASSED: No legacy constructs in added lines."
        exit 0
    fi
}

main "$@"

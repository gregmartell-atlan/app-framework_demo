# models

[![GitHub Super-Linter](https://github.com/atlanhq/models/workflows/Lint%20Code%20Base/badge.svg)](https://github.com/marketplace/actions/super-linter)

Models is a collection of typedefs for [atlan's metastore](https://github.com/atlanhq/atlas-metastore) ([Apache Atlas](https://atlas.apache.org/#/)). The contents of this repository from appropriate branches are seeded on every atlan instance using a [cron workflow](https://github.com/atlanhq/marketplace-packages/blob/master/packages/atlan/typedef-seeder/cronworkflows/typedef-seeder-cron.yaml) every 24 hours.

> [!WARNING]
> The types once seeded are immutable, the metastore does not allow deleting/modifying attributes. Please go through rigorous testing of your typedefs in your own tenant before you raise any PR to be merged into `master`. ONCE MERGED, IT IS PERMANENT AND CANNOT BE CHANGED.

## Process Overview

1. Create a feature branch from `master`
2. Edit or create Pkl files under `typedefs/`, use `/regenerate-typedefs` to regenerate the Atlas JSON, and commit to your feature branch
3. Canary your feature branch to an isolated dev tenant
4. Validate in your dev tenant: seeder finishes cleanly, typedefs work as intended (UI, programmatic, etc.)
5. Raise a PR from your feature branch to `master`
6. Address any and all failing PR checks
7. Once all PR checks are passing, request final review in [#collab-models](https://atlanhq.slack.com/archives/C067ECN8GFQ)

## What is a Typedef ?

A typedef is a specification of the attributes and relationships for an entity stored in the [metastore](https://github.com/atlanhq/atlas-metastore). You can read more about the metastore's type system [here](https://atlas.apache.org/#/TypeSystem). For example, have a look at the [Table.json](https://github.com/atlanhq/models/blob/readme-update/atlas/entityDefs/Referenceable/Asset/Catalog/SQL/Table.json) file to get an idea of what information about a SQL Table is stored in the metastore.

## Seeding Typedefs

Seeding typedefs is the process of making requests to the metastore using the file contents of this repository to install all the typedefs. This is done using the [@atlan/typedef-seeder](https://github.com/atlanhq/marketplace-packages/tree/master/packages/atlan/typedef-seeder) package. It's run when a new atlan instance is bootstrapped and it also runs as a cron workflow every 24 hours in every atlan cluster. You can read about how the typedef seeder works [here](https://www.notion.so/atlanhq/Video-Working-of-Typedef-Seeder-Bot-3bdb8bf127f24a75a600dd4b646b36bd).

We can only write data to the metastore after all the typedefs are seeded correctly. Thus it's necessary to successfully seed typedefs before you run any metadata crawling package.

### Deployment Channels

The typedef-seeder package always clones the `master` branch of this repository. All clusters run on the `main` channel.

```mermaid
graph LR
  n1[Developer] --merge PR--> n2[atlanhq/models master]
  n2 --> n3["typedef seeder cron workflow <br> (every 24 hrs)"]
  n3 --PUT/POST--> n4[metastore]
```

## Local Development and Testing

Clone the repository, branch out and then start editing/adding your typedefs in JSON files.

```bash
git clone git@github.com:atlanhq/models.git
```

Run npm install to setup the precommit hooks for help with formatting

```bash
npm i
```

### Testing

It is advised to use an isolated tenant when developing typedefs. You can use [Horizon](https://horizon.atlan.com) to onboard and offboard tenants for such purposes. If you are in a hurry, then you can use an existing tenant of any other member from your team. Just ping them on Slack and ask for an invite.

### Steps to test/seed your changes

The most effective way to test your typedefs is to ["canary" them into your isolated tenant](https://developer.atlan.com/toolkits/typedef/test-model/#canary-your-model). The linked documentation provides instructions on doing this both when you have cluster (`kubectl`) access and when you do not, and are entirely self-servable (no external approvals are required).

Whichever method you use, don't forget to actually then [seed your tenant](https://developer.atlan.com/toolkits/typedef/test-model/#seed-development-tenant) with the typedefs.

This will trigger the [@atlan/typedef-seeder](https://github.com/atlanhq/marketplace-packages/tree/master/packages/atlan/typedef-seeder) package to pull from your feature branch and send it to the metastore. Once the workflow succeeds, your typedefs will be available on your tenant.

### Iterating safely with `draftIteration`

Because Atlas types are permanent once seeded, you need a way to iterate freely on your typedef — renaming attributes, rethinking the model structure, removing fields you added by mistake — without locking yourself into half-finished names on your dev tenant. The `draftIteration` setting exists for exactly this purpose.

When you set `draftIteration` to a positive integer in your Pkl file:

```pkl
namespace = "MyConnector"
draftIteration = 1   // generates "MyConnectorV01" names during development
```

the toolkit appends a version suffix (`V01`, `V02`, …) to every generated type name and attribute prefix. Instead of seeding `MyConnectorTable` and `myConnectorTableSchema`, your dev tenant receives `MyConnectorV01Table` and `myConnectorV01TableSchema`. The final production names are never touched.

**Why this matters**: if you seed `MyConnectorTable` with an incomplete set of attributes and later realize you need to change something, you are stuck — those attributes are immutable. With `draftIteration`, the versioned draft types absorb all the churn. When you bump the number (`draftIteration = 2`), a fresh set of `V02` types is seeded alongside the old `V01` ones; iterate as many times as you need without consequence.

**Workflow**:
1. Set `draftIteration = 1` (or any positive integer) in your Pkl file before your first canary
2. Canary and seed your feature branch as normal — draft-suffixed types appear on your dev tenant
3. Validate, tweak, re-canary. If you make breaking changes (e.g. drop or rename an attribute), bump the number and reseed
4. When the model is final and you are satisfied with your dev-tenant testing, **remove `draftIteration` entirely** from the Pkl file and regenerate
5. Do one final canary/seed cycle to confirm the production names work end-to-end before raising your PR

> [!IMPORTANT]
> The CI conflict-checker will **fail your PR** if `draftIteration` is still present in any committed Pkl file. You must remove it before your branch is eligible to merge.

## Contributing Guide

> [!IMPORTANT]
> Create your typedefs in a feature branch from `master` -- NOT from any other branch, unless specifically advised to do so (for specific coordination purposes). Also do not force push into your feature branch after review.

You will need to add typedefs in this repository if you are building a feature that requires persisting data into Atlas (for discovery, etc). The most common case is when an Apps BU team builds a package for a new source. Below are some resources/checklists to make your life and the reviewer's life easier.

### How to develop typedefs

You must now use the [typedef toolkit](https://developer.atlan.com/toolkits/typedef/) to describe your new typedef. This ensures that your typedef follows standard and best practices, by providing various built-in checks and guardrails — which ultimately should help us improve consistency and the speed at which we can confidently define new typedefs.

> [!CAUTION]
> If you choose to ignore this, any request for your PR to be reviewed will also be ignored.

### Useful checks

- Commit the Pkl file for your typedef(s) to the top-level `typedefs` directory. (This is usually far easier to review than the individual, generated JSON files.)
- The directories of this repository under `atlas` are for the generated JSON output files. These are organized according to the asset hierarchy. Make sure the JSON generated for your new typedef is in a semantically-correct path.
- Check your descriptions are understandable, and written in sentence case (only the first word of any sentence is capitalized, and the description ends with a period).
- Check the typeVersion is bumped up if something changed in the model.

Most other points should be validated for you as part of the toolkit (and independent validators that run as PR checks). However, if you want to review a comprehensive checklist it is available [here](https://www.notion.so/atlanhq/Model-Review-Checklist-Atlan-2-0-c326f97210524329a714c36c7eace0d5). Go through this if you find your PR request failing a required check.

> [!Note]
> You can generate the JSON files using pkl command:
> `pkl eval typedefs/<filename>.pkl -m .`

### Raising PRs

Once you are done with your changes and reviews and want open a PR, you must minimally open it against the `master` branch. Without merging to `master`, your typedefs will not be generally available in any tenants other than your own.

## Referenced Notion Docs

- [PR Review Checklist](https://www.notion.so/atlanhq/Model-Review-Checklist-Atlan-2-0-c326f97210524329a714c36c7eace0d5)
- [How to define ES mappings via Models](https://www.notion.so/atlanhq/How-to-define-ES-mappings-via-models-for-Atlas-72ec7ecfce324256bd618fe8d97a5074)
- [How to create a tenant ?](https://www.notion.so/atlanhq/How-to-create-a-tenant-Detailed-version-b1d3c515a8c94111a6509344f302a8a7)
- [Working of the Typedef Seeder Bot](https://www.notion.so/atlanhq/Video-Working-of-Typedef-Seeder-Bot-3bdb8bf127f24a75a600dd4b646b36bd)
- [Atlas reset on model changes](https://www.notion.so/atlanhq/Atlas-reset-on-model-changes-4f2cb7d792dd4d9f86872ab82e682ef8)
- [Platform 101 / Metastore](https://www.notion.so/atlanhq/Metastore-9e0db331ebc6412cbbc6df1669553b4a)

## Contact

Please reach out on the [**#collab-models**](https://atlanhq.slack.com/archives/C067ECN8GFQ) channel on Slack with questions.

- Owners: chris@atlan.com

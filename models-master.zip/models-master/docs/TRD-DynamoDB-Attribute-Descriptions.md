# TRD: DynamoDB Attribute Descriptions

| Field      | Value                                                 |
| ---------- | ----------------------------------------------------- |
| **Linear** | [REQ-162](https://linear.app/atlan-epd/issue/REQ-162) |
| **Author** | Chandru Sugunan                                       |
| **Date**   | 2026-02-04                                            |
| **Status** | Implementation Complete - In Review                   |

---

## 1. Summary

Enable attribute-level descriptions for DynamoDB assets by introducing `DynamoDBAttribute` as a first-class entity type with full metadata support including data types, key indicators, and click-to-open-parent behavior.

**Customer:** Itau (Brazilian bank) - ODI initiative requiring rich metadata at all levels.

**Problem:** DynamoDB attributes aren't first-class assets. Users can't add descriptions, classifications, or tags to individual attributes.

---

## 2. Solution

### Type Inheritance Hierarchy (Multiple Inheritance)

DynamoDBAttribute uses **multiple inheritance** to inherit from both `DynamoDB` (for connector identity) and `SQL.Column` (for standard column behaviors):

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                   ATLAN TYPE INHERITANCE (MULTIPLE)                         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Referenceable                    ◄── Root type (guid, qualifiedName)       │
│       │                                                                     │
│       ▼                                                                     │
│     Asset                         ◄── Base asset (name, description,        │
│       │                               classifications, tags, owners, etc.)  │
│       ▼                                                                     │
│    Catalog                        ◄── Data catalog assets                   │
│       │                                                                     │
│       ├──────────────────────┬────────────────────┐                        │
│       ▼                      ▼                    ▼                         │
│      SQL                   NoSQL                  BI                        │
│       │                      │                    │                         │
│       │                      │                    └── Tableau, Looker, ...  │
│       │                      │                                              │
│       ├─────────┐            ▼                                              │
│       │         │         DynamoDB                                          │
│       ▼         │            │                                              │
│    Column ──────┼────────────┼──────────┐                                  │
│                 │            │          │                                   │
│                 │  ┌─────────┼──────────┼────────────┐                     │
│                 │  ▼         ▼          ▼            ▼                      │
│                 │ DynamoDBTable  SecondaryIndex  DynamoDBAttribute (NEW)   │
│                 │      │              │                   │                 │
│                 │      │              │          inherits from BOTH:        │
│                 │      │              │          - DynamoDB (connector)     │
│                 └──────┼──────────────┼──────────► Column (standard attrs) │
│                        │              │                                     │
│                        │              ├── DynamoDBGlobalSecondaryIndex      │
│                        │              └── DynamoDBLocalSecondaryIndex       │
│                        │                                                    │
│                        └───────── contains ─────────▶ DynamoDBAttribute     │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

### DynamoDB Asset Composition

```
DynamoDBTable
    ├── DynamoDBGlobalSecondaryIndex
    ├── DynamoDBLocalSecondaryIndex
    └── DynamoDBAttribute (NEW)
            │
            ├── Inherited from SQL.Column:
            │   ├── tableQualifiedName (link to parent)
            │   ├── dataType (S, N, B, etc.)
            │   ├── isPartition (boolean)
            │   ├── isSort (boolean)
            │   ├── order (position in table)
            │   └── table (relationship to parent)
            │
            └── Inherited from DynamoDB:
                └── (connector identity)
```

### Entity Model (Inherited from SQL.Column)

| Attribute            | Type    | Source     | Purpose                                                 |
| -------------------- | ------- | ---------- | ------------------------------------------------------- |
| `tableQualifiedName` | string  | SQL.Column | Links attribute to parent table (indexed for filtering) |
| `dataType`           | string  | SQL.Column | Data type: S, N, B, SS, NS, BS, M, L, NULL, BOOL        |
| `isPartition`        | boolean | SQL.Column | Whether attribute is partition key                      |
| `isSort`             | boolean | SQL.Column | Whether attribute is sort key                           |
| `order`              | int     | SQL.Column | Position within table (1-based)                         |
| `table`              | rel     | SQL.Column | Relationship to parent DynamoDBTable                    |

**Note:** DynamoDBAttribute has no custom attributes - all column-related attributes are inherited from `SQL.Column`.

### Relationship

```
DynamoDBTable (1) ──contains──▶ (*) DynamoDBAttribute
Relationship: dynamo_db_table_dynamo_db_attributes (AGGREGATION)
```

### Architectural Decision: Inherit from SQL.Column

**Decision:** `DynamoDBAttribute` inherits from BOTH `DynamoDB` AND `SQL.Column` using Pkl's multiple inheritance.

**Context:** After PR review feedback, we re-evaluated the inheritance approach and determined that inheriting from `SQL.Column` provides significant benefits with minimal downsides.

#### Why Multiple Inheritance is Correct:

| Benefit                      | Description                                                    |
| ---------------------------- | -------------------------------------------------------------- |
| **Standard attribute names** | Uses `isPartition`, `isSort`, `order`, `dataType` - no mapping |
| **Frontend compatibility**   | Works with existing column display logic out-of-the-box        |
| **Consistent API**           | Same attribute names as other column types in Atlan            |
| **Reduced frontend code**    | No custom `isPartition()` / `isSort()` checks needed           |
| **Automatic relationship**   | `table` relationship handled by Column infrastructure          |
| **Future-proof**             | Gains any future Column enhancements automatically             |

#### What SQL.Column Provides:

| Attribute Category | Attributes Used by DynamoDB                  | Attributes Unused (OK to ignore) |
| ------------------ | -------------------------------------------- | -------------------------------- |
| **Key indicators** | `isPartition`, `isSort`                      | `isPrimary`, `isForeign`         |
| **Ordering**       | `order`                                      | -                                |
| **Data type**      | `dataType`                                   | `precision`, `numericScale`      |
| **Parent link**    | `tableQualifiedName`, `table` (relationship) | -                                |
| **Statistics**     | -                                            | `histogram`, `mean`, etc.        |

#### Comparison with Previous Approach:

| Aspect           | Previous (Custom Attrs)         | Current (Inherit Column) |
| ---------------- | ------------------------------- | ------------------------ |
| Attribute names  | `dynamoDBIsPartitionKey`, etc.  | `isPartition`, etc.      |
| Frontend changes | ~50 lines custom mapping        | ~10 lines (simplified)   |
| API consistency  | Different from other connectors | Same as SQL columns      |
| Maintenance      | Must update DynamoDB separately | Inherits Column updates  |
| Typedef size     | 5 custom attributes             | 0 custom attributes      |

#### NoSQL Patterns in Atlan Codebase (Updated):

| Connector     | Approach            | Assessment                           |
| ------------- | ------------------- | ------------------------------------ |
| **MongoDB**   | Inherits SQL.Column | ✅ Standard column behavior          |
| **DynamoDB**  | Inherits SQL.Column | ✅ Consistent with MongoDB           |
| **Cassandra** | Own Column type     | ⚠️ Legacy approach, more maintenance |

**Conclusion:** Multiple inheritance from `SQL.Column` provides the best balance of consistency, maintainability, and frontend compatibility.

---

## 3. Implementation

### Backend (models repo) - Branch: `feature/dynamodb-attribute-entity`

| Change                         | File                                    | Lines     |
| ------------------------------ | --------------------------------------- | --------- |
| New `DynamoDBAttribute` entity | `typedefs/DynamoDB.pkl`                 | +10       |
| Inherits from `SQL.Column`     | `typedefs/DynamoDB.pkl`                 |           |
| Containment relationship       | `typedefs/DynamoDB.pkl`                 |           |
| Generated JSON                 | `atlas/.../DynamoDBAttribute.json`      | +16 (new) |
| Relationship JSON              | `atlas/.../DynamoDB_relationships.json` | +27       |
| Removed redundant test         | `toolkit/.../DynamoDBTest.pkl`          | -156      |

**Total: 6 files changed, +31 insertions, -185 deletions (net -154 lines)**

#### Pkl Definition

```pkl
[Attribute] {
  description = "Represents an attribute (column) in a DynamoDB table."
  superTypes { SQL.types["Column"] }  // Multiple inheritance: DynamoDB + Column
  useLocalTypeAsPrefix = true
}
```

#### Generated JSON (`DynamoDBAttribute.json`)

```json
{
  "entityDefs": [
    {
      "name": "DynamoDBAttribute",
      "description": "Represents an attribute (column) in a DynamoDB table.",
      "superTypes": ["DynamoDB", "Column"],
      "attributeDefs": []
    }
  ]
}
```

### Frontend (atlan-frontend) - Branch: `feature/dynamodb-attribute-entity`

**Simplified due to Column inheritance** - Uses standard Column attributes, reducing custom code.

| Change                        | File                     | Description                                                  |
| ----------------------------- | ------------------------ | ------------------------------------------------------------ |
| **Static asset type config**  | `assetTypes.ts`          | Added `DynamoDBAttribute` with `table` relationship          |
| Column Preview + Columns tab  | `getAssetTypes.ts`       | Added tabs using `tableQualifiedName` (standard Column attr) |
| DynamoDBAttribute asset type  | `getAssetTypes.ts`       | Full asset type config for discovery                         |
| **DynamoDBAttribute filters** | `getAssetTypes.ts`       | Filters using standard `isPartition`, `isSort`, `dataType`   |
| **Click-to-open-parent**      | `assetInfoUtils.ts`      | Added `getProfilePath` using `table` relationship            |
| **Child asset type**          | `index.ts`               | Added `'DynamoDBAttribute'` to `ChildAssetTypes` array       |
| Unit tests - getAssetTypes    | `getAssetTypes.spec.ts`  | 40 tests                                                     |
| Unit tests - assetInfoUtils   | `assetInfoUtils.spec.ts` | 123 tests                                                    |
| Unit tests - useAssetInfo     | `useAssetInfo.spec.ts`   | 15 tests (including 2 for DynamoDB getProfilePath)           |

**Total: 6 files, ~200 lines**

#### Key Simplifications from Column Inheritance:

| Feature         | Previous (Custom)                                  | Now (Inherited)                   |
| --------------- | -------------------------------------------------- | --------------------------------- |
| Data type       | `columnDataTypeAttribute: 'dynamoDBAttributeType'` | Uses standard `dataType`          |
| Ordering        | `columnOrderAttribute: 'dynamoDBOrder'`            | Uses standard `order`             |
| Key icon checks | Custom `dynamoDBIsPartitionKey` checks             | Standard `isPartition` works      |
| Parent link     | `dynamoDBTable` relationship                       | Standard `table` relationship     |
| Filters         | Custom attribute names                             | Standard Column filter attributes |

### Key Frontend Code

#### Static Asset Type Configuration (`assetTypes.ts`)

```typescript
// Added to assetTypeList for projection system
{
    id: 'DynamoDBAttribute',
    label: 'DynamoDB Column',
    fullLabel: 'DynamoDB Column',
    image: 'DynamoDB',
    source: 'dynamodb',
    categoryType: 'NoSQL',
    relationships: ['table'],  // Standard Column relationship (inherited)
    priorityOrder: 4,
    lineageGraph: {
        isPort: true,
        parentNodes: ['table'],  // Standard Column parent
    },
    projections: {
        required: ['table'],     // Standard Column relationship
        additional: [
            'tableQualifiedName',  // Standard Column attributes
            'dataType',
            'isPartition',
            'isSort',
            'order',
        ],
    },
}
```

#### Click-to-Open-Parent (`assetInfoUtils.ts`)

```typescript
} else if (assetType(asset) === 'DynamoDBAttribute') {
    // Uses standard 'table' relationship (inherited from Column)
    const tableGuid = asset?.attributes?.table?.guid
    if (tableGuid) {
        return `/assets/${tableGuid}/overview?column=${asset?.guid}`
    }
    return `/assets/not_found`
}
```

#### Child Asset Types (`index.ts`)

```typescript
export const ChildAssetTypes = [
  "Column",
  // ... existing entries
  Entity.CassandraColumn,
  "DynamoDBAttribute", // NEW - enables click-to-open-parent
  Entity.TableauWorksheetField,
  // ...
];
```

#### Column Tab Configuration (`getAssetTypes.ts`)

```typescript
// Simplified - uses standard Column attributes
getColumnsTab({
  t,
  additional: {
    columnTypeName: "DynamoDBAttribute",
    columnForeignKeyQualifiedNameAttribute: "tableQualifiedName", // Standard
    nestedColumnSupported: false,
    hideColumnCount: true,
    // No need for columnDataTypeAttribute - uses standard 'dataType'
    // No need for columnOrderAttribute - uses standard 'order'
    // No need for additionalAttributesToFetch - standard attrs fetched automatically
  },
});
```

---

## 4. Test Coverage

| Repo                      | Tests   | Coverage                                                      |
| ------------------------- | ------- | ------------------------------------------------------------- |
| frontend (getAssetTypes)  | 40      | Config, tabs, filters, DynamoDBAttribute using standard attrs |
| frontend (assetInfoUtils) | 123     | Including tests for DynamoDB getProfilePath                   |
| frontend (useAssetInfo)   | 15      | Including 2 tests for DynamoDB getProfilePath (click-to-open) |
| **Total**                 | **178** |                                                               |

```bash
# Run frontend tests
npm run test -- --run src/constant/source/noSql/dynamoDB/__tests__/
npm run test -- --run src/utils/assetInfo/__tests__/assetInfoUtils.spec.ts
npm run test -- --run src/composables/discovery/__tests__/useAssetInfo.spec.ts
```

---

## 5. Deployment

```
1. Push models branch → 2. Run typedef-seeder → 3. Create test data → 4. Test UI → 5. Commit frontend
```

### Deployment Status

| Step                                          | Status                                     |
| --------------------------------------------- | ------------------------------------------ |
| Models branch pushed                          | ✅ Done (`f52995c3`)                       |
| typedef-seeder completed                      | ✅ Done                                    |
| Test data created                             | ✅ Done                                    |
| DynamoDBAttribute static config added         | ✅ Done (enables projections)              |
| DynamoDBAttribute asset type in getAssetTypes | ✅ Done (enables Asset type filter)        |
| additionalAttributesToFetch added             | ✅ Done (enables key icons)                |
| columnDataTypeAttribute added                 | ✅ Done (enables data type display)        |
| Click-to-open-parent behavior                 | ✅ Done (ChildAssetTypes + getProfilePath) |
| portsAttributesProjections updated            | ✅ Done (global projections)               |
| UI verification                               | ✅ Done                                    |
| Frontend committed                            | ✅ Done                                    |

**Rollback:** Revert PRs. Note: typedefs are immutable once deployed.

---

## 6. Test Data

### Products Table (New - with proper relationships)

| Asset            | GUID                                   |
| ---------------- | -------------------------------------- |
| products (Table) | `8765322c-3f70-4f41-a720-4daaaeebe095` |

| Attribute      | Type | Key | Order | tableGuid |
| -------------- | ---- | --- | ----- | --------- |
| product_id     | S    | PK  | 1     | ✅ Set    |
| category       | S    | SK  | 2     | ✅ Set    |
| price          | N    | -   | 3     | ✅ Set    |
| stock_quantity | N    | -   | 4     | ✅ Set    |
| product_name   | S    | -   | 5     | ✅ Set    |

### Connection

- **Name**: DynamoDB Orders Connection
- **QualifiedName**: `default/dynamodb/1770239709`

---

## 7. Risks

| Risk                                       | Mitigation                                             |
| ------------------------------------------ | ------------------------------------------------------ |
| Typedef immutability                       | Thorough testing before deploy                         |
| Search index lag                           | Wait for ES indexing (~30s)                            |
| Attribute name conflicts                   | Used `dynamoDB` prefix for all attributes              |
| Click-to-open-parent requires relationship | Test data created with proper `relationshipAttributes` |

---

## 8. API Example

### Creating DynamoDBAttribute with Relationship

```bash
# Step 1: Create the table first
curl -X POST "https://{tenant}.atlan.com/api/meta/entity/bulk" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "entities": [{
      "typeName": "DynamoDBTable",
      "attributes": {
        "qualifiedName": "default/dynamodb/123/us-east-1/products",
        "name": "products",
        "connectionQualifiedName": "default/dynamodb/123",
        "connectorName": "dynamodb",
        "dynamoDBPartitionKey": "product_id",
        "dynamoDBSortKey": "category"
      }
    }]
  }'

# Step 2: Create attributes using standard Column attributes
curl -X POST "https://{tenant}.atlan.com/api/meta/entity/bulk" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "entities": [{
      "typeName": "DynamoDBAttribute",
      "attributes": {
        "qualifiedName": "default/dynamodb/123/us-east-1/products/product_id",
        "name": "product_id",
        "description": "Unique product identifier (partition key)",
        "tableQualifiedName": "default/dynamodb/123/us-east-1/products",
        "dataType": "S",
        "isPartition": true,
        "isSort": false,
        "order": 1,
        "connectionQualifiedName": "default/dynamodb/123",
        "connectorName": "dynamodb"
      },
      "relationshipAttributes": {
        "table": {
          "typeName": "DynamoDBTable",
          "guid": "<TABLE_GUID>"
        }
      }
    }]
  }'
```

**Note:** DynamoDBAttribute uses standard Column attributes (`tableQualifiedName`, `dataType`, `isPartition`, `isSort`, `order`, `table`) inherited from `SQL.Column`.

**IMPORTANT**: The `relationshipAttributes.table` is required for click-to-open-parent to work. Without it, clicking on an attribute in Discovery will show `/assets/not_found`.

### DynamoDB Data Types Reference

| Code | Type       | Description                  |
| ---- | ---------- | ---------------------------- |
| S    | String     | UTF-8 encoded string         |
| N    | Number     | Numeric (integer or decimal) |
| B    | Binary     | Binary data                  |
| SS   | String Set | Set of strings               |
| NS   | Number Set | Set of numbers               |
| BS   | Binary Set | Set of binary values         |
| M    | Map        | JSON-like nested object      |
| L    | List       | Ordered array                |
| NULL | Null       | Null value                   |
| BOOL | Boolean    | true/false                   |

---

## 9. Naming Convention

**Important: Use connector-specific labels consistently across all UI surfaces.**

| Layer                  | Naming                          | Example                                 |
| ---------------------- | ------------------------------- | --------------------------------------- |
| Typedef entity         | Connector-specific              | `DynamoDBAttribute`, `CassandraColumn`  |
| Asset type `label`     | **Connector-specific**          | `"DynamoDB Column"`, `"DynamoDB Table"` |
| Asset type `fullLabel` | Same as label                   | `"DynamoDB Column"`, `"DynamoDB Table"` |
| Filter facet `label`   | **Must match asset type label** | `"DynamoDB Column"`, `"DynamoDB Table"` |

**Why not generic labels?**

Using generic labels like `"Column"` or `"Table"` causes duplicate entries in the Asset Type filter dropdown:

- "Table 1.7K" (SQL Table)
- "Table 3" (DynamoDB Table) ← Confusing duplicate!

By using connector-specific labels (`"DynamoDB Table"`, `"DynamoDB Column"`), each asset type has a unique, identifiable entry in the filter.

**Filter Facet Labels:** The filter configuration's `label` property appears in the "ASSET TYPE FILTERS" section. It must match the asset type label for consistency:

```typescript
// Asset type config
{ id: 'DynamoDBAttribute', label: t('DynamoDB Column'), ... }

// Filter config (must match)
{ id: 'dynamodbattribute', label: t('DynamoDB Column'), includes: ['DynamoDBAttribute'], ... }
```

**Note:** GSI and LSI already use unique abbreviations (`"GSI"`, `"LSI"`) which don't conflict with other types.

---

## 10. Click-to-Open-Parent Pattern

When clicking a "child" asset (column/attribute) in Discovery, it should open the parent (table) and anchor on that child. This requires:

### 1. Add to `ChildAssetTypes` array (`src/constant/source/index.ts`)

```typescript
export const ChildAssetTypes = [
  "Column",
  // ... existing entries
  "DynamoDBAttribute", // Add new child asset types here
];
```

### 2. Add `getProfilePath` handler (`src/utils/assetInfo/assetInfoUtils.ts`)

```typescript
} else if (assetType(asset) === 'DynamoDBAttribute') {
    // Uses standard 'table' relationship (inherited from Column)
    const tableGuid = asset?.attributes?.table?.guid
    if (tableGuid) {
        return `/assets/${tableGuid}/overview?column=${asset?.guid}`
    }
    return `/assets/not_found`
}
```

### 3. Add to static `assetTypeList` (`src/constant/source/noSql/dynamoDB/assetTypes.ts`)

```typescript
{
    id: 'DynamoDBAttribute',
    // ...
    projections: {
        required: ['table'],  // Standard Column relationship (inherited)
        additional: ['tableQualifiedName', 'dataType', 'isPartition', 'isSort', 'order'],
    },
}
```

**Note:** Because DynamoDBAttribute inherits from `SQL.Column`, it uses the standard `table` relationship - no custom projection configuration needed in `projection.ts`.

---

## 11. Key Icons Pattern

To display partition key (🔑) and sort key icons in Column Preview:

### Standard Column Approach (Used by DynamoDBAttribute)

Because DynamoDBAttribute inherits from `SQL.Column`, it uses the standard `isPartition` and `isSort` attributes. **No custom checks needed in `assetInfoUtils.ts`**.

The existing `isPartition()` and `isSort()` functions work automatically:

```typescript
// Already handles DynamoDBAttribute via standard 'isPartition' attribute
const isPartition = (asset: T) =>
  getAttributeValue(asset, "isPartition") ||
  getAttributeValue(asset, "cassandraColumnIsPartitionKey");

// Already handles DynamoDBAttribute via standard 'isSort' attribute
const isSort = (asset: T) => getAttributeValue(asset, "isSort");
```

### Benefit of Column Inheritance

No additional `additionalAttributesToFetch` configuration needed - standard Column attributes are fetched automatically by the column display infrastructure.

---

## 12. Column Ordering Pattern

Because DynamoDBAttribute inherits from `SQL.Column`, it uses the standard `order` attribute for column ordering.

### Automatic Ordering (No Configuration Needed)

The `columnsWidget.vue` component defaults to using the `order` attribute, which DynamoDBAttribute inherits from Column. **No `columnOrderAttribute` override needed.**

```typescript
// Simplified config - uses default 'order' attribute
getColumnsTab({
  t,
  additional: {
    columnTypeName: "DynamoDBAttribute",
    columnForeignKeyQualifiedNameAttribute: "tableQualifiedName",
    nestedColumnSupported: false,
    // No columnOrderAttribute needed - uses inherited 'order'
  },
});
```

**How it works:** The `order` attribute is inherited from `SQL.Column` and is fetched automatically. Columns are sorted by this value, maintaining stable ordering even when descriptions are updated.

---

## 13. Filters Pattern

Because DynamoDBAttribute inherits from `SQL.Column`, filters use standard Column attribute names.

### Filter Configuration Using Standard Attributes

```typescript
{
    id: 'DynamoDBAttribute',
    // ... other config
    discovery: {
        filters: [
            {
                id: 'dynamodbattribute',
                label: t('DynamoDB Column'),
                component: 'properties',
                includes: ['DynamoDBAttribute'],
                options: {
                    logoType: 'icon',
                    icon: 'DynamoDB',
                },
                attributes: [
                    {
                        name: 'isPartition',        // Standard Column attribute
                        displayName: t('Partition key'),
                        typeName: 'boolean',
                    },
                    {
                        name: 'isSort',             // Standard Column attribute
                        displayName: t('Sort key'),
                        typeName: 'boolean',
                    },
                    {
                        name: 'dataType',           // Standard Column attribute
                        displayName: t('Data type'),
                        typeName: 'string',
                    },
                ],
                isDeleted: false,
                isDisabled: false,
                exclude: false,
                analyticsKey: 'dynamodbattribute',
            },
        ],
        // ... other config
    },
}
```

**Benefit:** Using standard Column attributes means filters work consistently with other column types across Atlan.

---

## 14. Future Work

- **V1:** Auto-extract attributes via DynamoDB connector (marketplace-scripts)
- **Enhancements:**
  - Nested attribute support for Map/List types
  - Secondary index attribute indicators
  - Attribute statistics (cardinality, null percentage)

---

## 15. References

| Resource            | Link                                                                                                          |
| ------------------- | ------------------------------------------------------------------------------------------------------------- |
| Models Branch       | [feature/dynamodb-attribute-entity](https://github.com/atlanhq/models/tree/feature/dynamodb-attribute-entity) |
| Test Tenant         | https://apps-resiliency-gcp.atlan.com                                                                         |
| Workspace           | `enpla1cp89`                                                                                                  |
| Products Table GUID | `8765322c-3f70-4f41-a720-4daaaeebe095`                                                                        |

---

_Last updated: 2026-02-05_

// Load the typedef index and graph data
let typeDefIndex = {};
let globalGraphData = {}; // Renamed to avoid conflict with local variables

// Construct the base URL for fetching data
// const baseUrl = window.location.origin + window.location.pathname;
// Fetch both data files before showing any asset details
async function initializeData() {
    try {
        const [indexResponse, graphResponse] = await Promise.all([
            fetch(`${baseUrl}/data/typedef-index.json`),
            fetch(`${baseUrl}/data/typedef-graph.json`)
        ]);
        
        typeDefIndex = await indexResponse.json();
        globalGraphData = await graphResponse.json();
        
        // Handle URL params after data is loaded
        handleUrlParams();
    } catch (error) {
        console.error('Error loading data:', error);
    }
}

function initializeGraphVisualization() {
    // Create a container for the graph
    const container = document.getElementById('graph-container');
    if (!container) {
        console.warn('Graph container not found');
        return;
    }

    // Configure the graph visualization
    const options = {
        nodes: {
            shape: 'box',
            margin: 20,
            borderWidth: 1,
            shadow: true,
            font: {
                size: 14
            },
            widthConstraint: {
                minimum: 150
            },
            heightConstraint: {
                minimum: 40
            }
        },
        edges: {
            smooth: {
                enabled: true,
                type: 'dynamic',
                roundness: 0.5
            },
            font: {
                size: 12,
                color: '#4B5563',
                bold: '500',
                align: 'horizontal'
            },
            width: 2,
            arrows: {
                to: {
                    enabled: true,
                    scaleFactor: 1
                }
            }
        },
        physics: {
            enabled: true,
            solver: 'forceAtlas2Based',
            forceAtlas2Based: {
                gravitationalConstant: -500,
                centralGravity: 0.01,
                springLength: 200,
                springConstant: 0.08,
                damping: 0.4,
                avoidOverlap: 1
            },
            stabilization: {
                enabled: true,
                iterations: 1000,
                updateInterval: 25
            }
        }
    };

    // Create the network visualization
    const network = new vis.Network(container, globalGraphData, options);

    // Add event listeners
    network.on('click', function(params) {
        if (params.nodes.length > 0) {
            const nodeId = params.nodes[0];
            showNodeDetails(nodeId);
        }
    });

    // Add search functionality
    const searchInput = document.getElementById('default-search');
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            const matchingNodes = globalGraphData.nodes.filter(node => 
                node.label.toLowerCase().includes(searchTerm) ||
                node.description.toLowerCase().includes(searchTerm)
            );
            
            // Highlight matching nodes
            const nodeIds = new Set(matchingNodes.map(node => node.id));
            network.setSelection({
                nodes: Array.from(nodeIds)
            });
        });
    }

    // After creating the network, ensure proper spacing
    network.on("stabilizationIterationsDone", function() {
        // Get the main node's dimensions
        const mainNodeBox = network.getBoundingBox(entityDef.name);
        const mainNodeWidth = mainNodeBox.right - mainNodeBox.left;
        
        // Calculate desired node width in pixels (on screen)
        const desiredNodeWidth = 200;
        const scale = desiredNodeWidth / mainNodeWidth;
        
        // Get the position of the main node
        const position = network.getPosition(entityDef.name);
        
        // Move to the main node with our calculated scale
        network.moveTo({
            position: position,
            scale: scale,
            animation: {
                duration: 1000,
                easingFunction: 'easeInOutQuad'
            }
        });
    });
}

function showNodeDetails(nodeId) {
    const detailsContainer = document.getElementById('asset-details');
    if (!detailsContainer) return;

    // Find the node in the graph data
    const node = globalGraphData.nodes.find(n => n.id === nodeId);
    if (!node) return;

    // Find related edges
    const relatedEdges = globalGraphData.edges.filter(edge => 
        edge.from === nodeId || edge.to === nodeId
    );

    // Find the typedef details from the index
    const typeDefDetails = typeDefIndex.entityDefs.find(def => def.name === nodeId);

    // Create the details HTML
    let html = `
        <div class="p-4">
            <h2 class="text-2xl font-bold mb-4">${node.label}</h2>
            <p class="text-gray-600 mb-4">${node.description}</p>
            
            ${typeDefDetails ? `
                <div class="mb-4">
                    <h3 class="text-lg font-semibold">Source Path:</h3>
                    <code class="bg-gray-100 p-2 rounded">${typeDefDetails.path}</code>
                </div>
            ` : ''}

            <div class="mb-4">
                <h3 class="text-lg font-semibold">Relationships:</h3>
                <ul class="list-disc pl-5">
                    ${relatedEdges.map(edge => `
                        <li class="mb-2">
                            <span class="font-medium">${edge.type}:</span>
                            ${edge.from === nodeId ? 
                                `to <span class="text-blue-600">${edge.to}</span>` : 
                                `from <span class="text-blue-600">${edge.from}</span>`}
                            ${edge.name ? `(${edge.name})` : ''}
                        </li>
                    `).join('')}
                </ul>
            </div>
        </div>
    `;

    detailsContainer.innerHTML = html;
}

const searchInput = document.getElementById('search-input');
const searchResults = document.getElementById('search-results');
const assetDetails = document.getElementById('asset-details');

// Add this function to update URL without reloading the page
function updateUrlWithAsset(path) {
    const url = new URL(window.location);
    url.searchParams.set('asset', path);
    window.history.pushState({}, '', url);
}

// Update showAssetProfile to set URL parameter
async function showAssetProfile(path) {
    // Update URL for sharing
    updateUrlWithAsset(path);
    
    const searchContainer = document.getElementById('search-container');
    const searchResults = document.getElementById('search-results');
    
    try {
        const response = await fetch(`${baseUrl}/${path}`);
        const data = await response.json();
        const entityDef = data.entityDefs[0];
        
        // Track loaded supertype attributes
        const supertypeAttributes = new Map();

        // Load supertype attributes if any
        if (entityDef.superTypes && entityDef.superTypes.length > 0) {
            for (const superType of entityDef.superTypes) {
                // Find the supertype definition in the index
                const supertypePath = typeDefIndex.entityDefs.find(def => def.name === superType)?.path;
                if (supertypePath) {
                    try {
                        const supertypeResponse = await fetch(`${baseUrl}/${supertypePath}`);
                        const supertypeData = await supertypeResponse.json();
                        const supertypeDef = supertypeData.entityDefs[0];
                        
                        if (supertypeDef.attributeDefs && supertypeDef.attributeDefs.length > 0) {
                            supertypeAttributes.set(superType, supertypeDef.attributeDefs);
                        }
                    } catch (error) {
                        console.error(`Error loading supertype ${superType}:`, error);
                    }
                }
            }
        }
        
        // Move search bar up
        searchContainer.classList.add('justify-start');
        searchContainer.classList.remove('justify-center');
        
        // Show asset profile with inherited attributes
        searchResults.innerHTML = renderAssetProfile(data, supertypeAttributes);

        // Reset right panel and initialize graph
        const rightPanel = document.getElementById('right-panel');
        rightPanel.innerHTML = `
            <div class="flex">
                <div id="graph-container" class="w-2/3 h-screen relative"></div>
                <div id="asset-details" class="w-1/3 h-screen overflow-y-auto border-l"></div>
            </div>
        `;

        // Initialize graph visualization
        const visData = {
            nodes: new vis.DataSet(),
            edges: new vis.DataSet()
        };

        // Add nodes and edges
        const nodesList = [];
        const uniqueNodeIds = new Set();

        // Add main entity node
        nodesList.push({
            id: entityDef.name,
            label: entityDef.name,
            color: '#4f46e5',
            font: { color: 'white' }
        });
        uniqueNodeIds.add(entityDef.name);

        // Add supertype nodes and edges
        if (entityDef.superTypes) {
            entityDef.superTypes.forEach(superType => {
                if (!uniqueNodeIds.has(superType)) {
                    nodesList.push({
                        id: superType,
                        label: superType,
                        color: '#818cf8'
                    });
                    uniqueNodeIds.add(superType);
                }
                visData.edges.add({
                    from: superType,
                    to: entityDef.name,
                    arrows: { to: { enabled: true } },
                    dashes: true,
                    label: 'EXTENDS',
                    color: { color: '#818cf8' }
                });
            });
        }

        // Add relationship nodes and edges
        const relationships = globalGraphData.relationships.filter(rel => {
            // Check if this relationship involves our entity
            const isInvolved = rel.end1.type === entityDef.name || rel.end2.type === entityDef.name;
            // Check if it's not a self-referential relationship (either direct or through relationship)
            const isNotSelfRef = rel.end1.type !== rel.end2.type && 
                                rel.end1.type !== entityDef.name || rel.end2.type !== entityDef.name;
            return isInvolved && isNotSelfRef;
        });

        relationships.forEach(rel => {
            const otherType = rel.end1.type === entityDef.name ? rel.end2.type : rel.end1.type;
            
            // Add related entity node if not already added
            if (!uniqueNodeIds.has(otherType)) {
                nodesList.push({
                    id: otherType,
                    label: otherType,
                    color: '#93c5fd'  // lighter blue for related nodes
                });
                uniqueNodeIds.add(otherType);
            }

            // Add relationship edge
            visData.edges.add({
                from: rel.end1.type,
                to: rel.end2.type,
                arrows: { to: { enabled: true } },
                label: rel.relationshipCategory || rel.category || 'RELATIONSHIP',
                color: { color: '#93c5fd' },
                font: { 
                    size: 12,
                    color: '#4B5563',
                    bold: '500',
                    align: 'horizontal',
                    multi: false,
                    vadjust: -10
                },
                smooth: {
                    type: 'cubicBezier',
                    forceDirection: 'vertical',
                    roundness: 0.5
                }
            });
        });

        // Add nodes to visualization
        visData.nodes.add(nodesList);

        // Configure visualization options
        const options = {
            nodes: {
                shape: 'box',
                margin: 20,
                borderWidth: 1,
                shadow: true,
                font: {
                    size: 14
                },
                widthConstraint: {
                    minimum: 150
                },
                heightConstraint: {
                    minimum: 40
                }
            },
            edges: {
                smooth: {
                    enabled: true,
                    type: 'dynamic',
                    roundness: 0.5
                },
                font: {
                    size: 12,
                    color: '#4B5563',
                    bold: '500',
                    align: 'horizontal'
                },
                width: 2,
                arrows: {
                    to: {
                        enabled: true,
                        scaleFactor: 1
                    }
                }
            },
            physics: {
                enabled: true,
                solver: 'forceAtlas2Based',
                forceAtlas2Based: {
                    gravitationalConstant: -500,
                    centralGravity: 0.01,
                    springLength: 200,
                    springConstant: 0.08,
                    damping: 0.4,
                    avoidOverlap: 1
                },
                stabilization: {
                    enabled: true,
                    iterations: 1000,
                    updateInterval: 25
                }
            }
        };

        // Initialize network
        const container = document.getElementById('graph-container');
        const network = new vis.Network(container, visData, options);

        // Disable physics after initial layout
        network.on("stabilizationIterationsDone", function() {
            network.setOptions({ physics: { enabled: false } });
            
            // Ensure nodes are properly spaced
            const positions = network.getPositions();
            const nodeIds = Object.keys(positions);
            
            // Calculate node dimensions
            const nodeDimensions = {};
            nodeIds.forEach(id => {
                const boundingBox = network.getBoundingBox(id);
                nodeDimensions[id] = {
                    width: boundingBox.right - boundingBox.left,
                    height: boundingBox.bottom - boundingBox.top
                };
            });
            
            // Adjust positions to ensure minimum spacing
            nodeIds.forEach(id1 => {
                nodeIds.forEach(id2 => {
                    if (id1 !== id2) {
                        const pos1 = positions[id1];
                        const pos2 = positions[id2];
                        const dim1 = nodeDimensions[id1];
                        const dim2 = nodeDimensions[id2];
                        
                        // Calculate minimum required spacing
                        const minHorizontalSpacing = (dim1.width + dim2.width) / 2 + 100; // 100px padding
                        const minVerticalSpacing = (dim1.height + dim2.height) / 2 + 50;  // 50px padding
                        
                        // Adjust positions if needed
                        const dx = Math.abs(pos1.x - pos2.x);
                        const dy = Math.abs(pos1.y - pos2.y);
                        
                        if (dx < minHorizontalSpacing) {
                            const adjustment = (minHorizontalSpacing - dx) / 2;
                            if (pos1.x < pos2.x) {
                                network.moveNode(id1, pos1.x - adjustment, pos1.y);
                                network.moveNode(id2, pos2.x + adjustment, pos2.y);
                            } else {
                                network.moveNode(id1, pos1.x + adjustment, pos1.y);
                                network.moveNode(id2, pos2.x - adjustment, pos2.y);
                            }
                        }
                        
                        if (dy < minVerticalSpacing) {
                            const adjustment = (minVerticalSpacing - dy) / 2;
                            if (pos1.y < pos2.y) {
                                network.moveNode(id1, pos1.x, pos1.y - adjustment);
                                network.moveNode(id2, pos2.x, pos2.y + adjustment);
                            } else {
                                network.moveNode(id1, pos1.x, pos1.y + adjustment);
                                network.moveNode(id2, pos2.x, pos2.y - adjustment);
                            }
                        }
                    }
                });
            });
            
            // Final fit to ensure all nodes are visible
            network.fit({
                animation: {
                    duration: 1000,
                    easingFunction: 'easeInOutQuad'
                },
                padding: 50
            });
        });

        // Add zoom controls
        addZoomControls(network);

        // Add double-click handler for navigation
        network.on("doubleClick", function(params) {
            if (params.nodes.length > 0) {
                const nodeId = params.nodes[0];
                // Find the node's path in typeDefIndex
                const nodeDef = typeDefIndex.entityDefs.find(def => def.name === nodeId);
                if (nodeDef) {
                    showAssetProfile(nodeDef.path);
                }
            }
        });

    } catch (error) {
        console.error('Error loading asset profile:', error);
        searchResults.innerHTML = `
            <div class="text-red-500 p-4">
                Error loading asset profile: ${error.message}
            </div>
        `;
    }
}

// Add function to handle URL parameters on page load
async function handleUrlParams() {
    const urlParams = new URLSearchParams(window.location.search);
    const assetPath = urlParams.get('asset');
    
    if (assetPath) {
        // Initialize data if needed
        if (!globalGraphData || !typeDefIndex) {
            await initializeData();
        }
        
        // Show the asset profile
        await showAssetProfile(assetPath);
        
        // Move search bar up since we're showing content
        const searchContainer = document.getElementById('search-container');
        searchContainer.classList.add('justify-start');
        searchContainer.classList.remove('justify-center');
    }
}

// Update the window load event listener
window.addEventListener('load', async () => {
    await initializeData();
    await handleUrlParams(); // Handle URL params after data is initialized
    
    // Only show welcome screen if no asset parameter in URL
    if (!new URLSearchParams(window.location.search).has('asset')) {
        showWelcomeScreen();
    }
});

// Handle browser back/forward navigation
window.addEventListener('popstate', async () => {
    await handleUrlParams();
});

function renderSearchResult(item, query) {
    return `
        <div class="p-4 bg-white rounded-lg shadow hover:shadow-md transition-shadow cursor-pointer" 
             onclick="showAssetProfile('${item.path}')">
            <h3 class="text-xl font-semibold text-gray-900">${item.name}</h3>
            <p class="text-gray-500 mt-1">${item.description || ''}</p>
        </div>
    `;
}

function escapeHTML(str) {
    return str.replace(/[<>&"'`]/g, (char) => ({
        '<': '&lt;',
        '>': '&gt;',
        '&': '&amp;',
        '"': '&quot;',
        "'": '&#39;',
        '`': '&#96;'
    }[char]));
}

function renderAttributes(attributes) {
    return attributes.map(attr => `
        <div class="border-b border-gray-100 py-4 px-6">
            <div class="flex justify-between items-start gap-4">
                <div class="flex-1">
                    <h4 class="font-medium text-gray-900 mb-1">${attr.name}</h4>
                    <p class="text-sm text-gray-500 break-words">${escapeHTML(attr.description) || ''}</p>
                </div>
                <span class="px-3 py-1 text-sm bg-blue-50 text-blue-700 rounded whitespace-nowrap">${escapeHTML(attr.typeName)}</span>
            </div>
        </div>
    `).join('');
}

function renderRelationships(relationships) {
    if (!relationships || !relationships.length) return '';
    return `
        <div class="mt-8">
            <h3 class="text-lg font-semibold mb-4">Relationships</h3>
            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">From</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Relationship</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">To</th>
                            <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        ${relationships.map(rel => {
                            // Get the correct type names from the relationship structure
                            const fromType = rel.end1?.type || rel.endDef1?.type;
                            const toType = rel.end2?.type || rel.endDef2?.type;
                            
                            // Find paths for both types
                            const fromTypePath = typeDefIndex.entityDefs.find(def => def.name === fromType)?.path;
                            const toTypePath = typeDefIndex.entityDefs.find(def => def.name === toType)?.path;
                            
                            return `
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        ${fromTypePath ? 
                                            `<a href="javascript:void(0)" 
                                                onclick="showAssetProfile('${fromTypePath}')" 
                                                class="font-medium text-indigo-600 hover:text-indigo-900">
                                                ${fromType}
                                            </a>` : 
                                            `<span class="text-gray-900">${fromType}</span>`
                                        }
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                        ${rel.relationshipCategory || rel.category || ''}
                                    </td>
                                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                                        ${toTypePath ? 
                                            `<a href="javascript:void(0)" 
                                                onclick="showAssetProfile('${toTypePath}')" 
                                                class="font-medium text-indigo-600 hover:text-indigo-900">
                                                ${toType}
                                            </a>` : 
                                            `<span class="text-gray-900">${toType}</span>`
                                        }
                                    </td>
                                    <td class="px-6 py-4 text-sm text-gray-500">${rel.description || ''}</td>
                                </tr>
                            `;
                        }).join('')}
                    </tbody>
                </table>
            </div>
        </div>
    `;
}

// Add this function near the top of the file
function showWelcomeScreen() {
    const rightPanel = document.getElementById('right-panel');
    if (!rightPanel) return;

    rightPanel.innerHTML = `
        <div class="h-full flex items-center justify-center p-8">
            <div class="text-center welcome-content max-w-2xl">
                <svg class="w-32 h-32 mx-auto mb-6" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <!-- Root Node -->
                    <circle cx="50" cy="20" r="8" fill="#4F46E5"/>
                    
                    <!-- Connecting Lines -->
                    <line x1="50" y1="28" x2="30" y2="48" stroke="#4F46E5" stroke-width="2"/>
                    <line x1="50" y1="28" x2="70" y2="48" stroke="#4F46E5" stroke-width="2"/>
                    <line x1="30" y1="56" x2="20" y2="76" stroke="#4F46E5" stroke-width="2"/>
                    <line x1="30" y1="56" x2="40" y2="76" stroke="#4F46E5" stroke-width="2"/>
                    <line x1="70" y1="56" x2="60" y2="76" stroke="#4F46E5" stroke-width="2"/>
                    <line x1="70" y1="56" x2="80" y2="76" stroke="#4F46E5" stroke-width="2"/>
                    
                    <!-- Level 2 Nodes -->
                    <circle cx="30" cy="50" r="6" fill="#4F46E5"/>
                    <circle cx="70" cy="50" r="6" fill="#4F46E5"/>
                    
                    <!-- Level 3 Nodes -->
                    <circle cx="20" cy="80" r="5" fill="#4F46E5"/>
                    <circle cx="40" cy="80" r="5" fill="#4F46E5"/>
                    <circle cx="60" cy="80" r="5" fill="#4F46E5"/>
                    <circle cx="80" cy="80" r="5" fill="#4F46E5"/>
                </svg>
                <h2 class="text-3xl font-bold text-gray-700 mb-4">
                    Welcome to Atlan TypeDefs Explorer
                </h2>
                <p class="text-gray-500">
                    Search for any type definition using the search bar on the left. <br>
                    You'll see detailed information and relationships here.
                </p>
            </div>
        </div>
    `;
}

// Update renderAssetProfile to accept supertypeAttributes
function renderAssetProfile(data, supertypeAttributes) {
    const entityDef = data.entityDefs[0];
    
    // Construct GitHub URL using the path from typeDefIndex
    const githubBaseUrl = 'https://github.com/atlanhq/models/blob/master/';
    const indexDef = typeDefIndex.entityDefs.find(def => def.name === entityDef.name);
    const githubUrl = indexDef ? githubBaseUrl + indexDef.path : null;
    
    return `
        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex justify-between items-start mb-6">
                <div>
                    <h2 class="text-2xl font-bold text-gray-900">${entityDef.name}</h2>
                    <p class="text-gray-600 mt-1">${entityDef.description || ''}</p>
                    ${entityDef.superTypes && entityDef.superTypes.length > 0 ? 
                        `<p class="text-sm text-gray-500 mt-2">Extends: ${entityDef.superTypes.join(', ')}</p>` : 
                        ''}
                </div>
                <div class="flex items-center gap-2">
                    ${githubUrl ? `
                        <a href="${githubUrl}" 
                           target="_blank" 
                           rel="noopener noreferrer" 
                           class="flex items-center gap-2 px-3 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors">
                            <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                                <path fill-rule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.338-2.22-.253-4.555-1.113-4.555-4.951 0-1.093.39-1.988 1.029-2.688-.103-.253-.446-1.272.098-2.65 0 0 .84-.27 2.75 1.026A9.564 9.564 0 0112 6.844c.85.004 1.705.115 2.504.337 1.909-1.296 2.747-1.027 2.747-1.027.546 1.379.202 2.398.1 2.651.64.7 1.028 1.595 1.028 2.688 0 3.848-2.339 4.695-4.566 4.943.359.309.678.92.678 1.855 0 1.338-.012 2.419-.012 2.747 0 .268.18.58.688.482A10.019 10.019 0 0022 12.017C22 6.484 17.522 2 12 2z" clip-rule="evenodd"/>
                            </svg>
                            View on GitHub
                        </a>
                    ` : ''}
                    <button 
                        class="text-gray-500 hover:text-gray-700" 
                        onclick="showSearchResults()">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
                        </svg>
                    </button>
                </div>
            </div>

            <div class="space-y-6">
                <div>
                    <h3 class="text-lg font-semibold mb-4">Attributes</h3>
                    <div class="bg-white rounded-lg divide-y divide-gray-100">
                        ${renderAttributes(entityDef.attributeDefs || [])}
                    </div>
                </div>

                ${Array.from(supertypeAttributes.entries()).map(([type, attrs]) => `
                    <div class="mt-6">
                        <div class="flex items-center gap-2 mb-2 cursor-pointer bg-gray-50 p-3 rounded-lg" 
                             onclick="this.nextElementSibling.classList.toggle('hidden')">
                            <h3 class="text-lg font-semibold text-gray-700">Inherited from ${type}</h3>
                            <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
                            </svg>
                        </div>
                        <div class="hidden bg-white rounded-lg shadow divide-y divide-gray-100">
                            ${renderAttributes(attrs)}
                        </div>
                    </div>
                `).join('')}

                ${renderRelationships(data.relationshipDefs)}
            </div>
        </div>
    `;
}

// Add function to show search results
function showSearchResults() {
    const searchInput = document.getElementById('search-input');
    const query = searchInput.value.trim();
    
    if (query.length >= 2) {
        performSearch(query);
    } else {
        const searchContainer = document.getElementById('search-container');
        searchContainer.classList.remove('justify-start');
        searchContainer.classList.add('justify-center');
        document.getElementById('search-results').innerHTML = '';
    }
}

// Debounce function to limit how often the search is performed
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Debounced search function
const debouncedSearch = debounce((query) => {
    const searchContainer = document.getElementById('search-container');
    
    if (query.length >= 2) {
        performSearch(query);
        // Add class to move search bar up
        searchContainer.classList.add('justify-start');
        searchContainer.classList.remove('justify-center');
    } else {
        searchResults.innerHTML = '';
        // Reset search bar to center when no results
        searchContainer.classList.remove('justify-start');
        searchContainer.classList.add('justify-center');
    }
}, 300);

searchInput.addEventListener('input', (e) => {
    const query = e.target.value.trim();
    debouncedSearch(query);
});

// Add this function to create zoom controls
function addZoomControls(network) {
    const container = document.getElementById('graph-container');
    
    const zoomControls = document.createElement('div');
    zoomControls.className = 'absolute bottom-4 right-4 flex flex-col gap-2 z-10';
    zoomControls.innerHTML = `
        <button class="bg-white p-2 rounded-lg shadow-lg hover:bg-gray-50 transition-colors" title="Zoom In">
            <svg class="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/>
            </svg>
        </button>
        <button class="bg-white p-2 rounded-lg shadow-lg hover:bg-gray-50 transition-colors" title="Zoom Out">
            <svg class="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 12H4"/>
            </svg>
        </button>
        <button class="bg-white p-2 rounded-lg shadow-lg hover:bg-gray-50 transition-colors" title="Fit View">
            <svg class="w-6 h-6 text-gray-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 8V4m0 0h4M4 4l5 5m11-5V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5v-4m0 4h-4m4 0l-5-5"/>
            </svg>
        </button>
    `;
    container.appendChild(zoomControls);

    // Add event listeners
    const [zoomIn, zoomOut, fitView] = zoomControls.children;
    zoomIn.onclick = () => network.moveTo({ scale: network.getScale() * 1.2 });
    zoomOut.onclick = () => network.moveTo({ scale: network.getScale() * 0.8 });
    fitView.onclick = () => network.fit();
}

// Update the performSearch function with better ranking
async function performSearch(query) {
    if (!typeDefIndex) {
        console.error('Type definitions not loaded');
        return;
    }

    const searchResults = document.getElementById('search-results');
    const queryLower = query.toLowerCase();
    
    try {
        // Create ranked results with scores
        const rankedResults = typeDefIndex.entityDefs
            .map(def => {
                const nameLower = def.name.toLowerCase();
                let score = 0;

                // Exact name match (highest priority)
                if (nameLower === queryLower) {
                    score += 100;
                }
                // Name starts with query
                else if (nameLower.startsWith(queryLower)) {
                    score += 80;
                }
                // Name contains query as a word
                else if (nameLower.includes(` ${queryLower}`) || nameLower.includes(`${queryLower} `)) {
                    score += 60;
                }
                // Name contains query anywhere
                else if (nameLower.includes(queryLower)) {
                    score += 40;
                }
                // Description matches
                if (def.description?.toLowerCase().includes(queryLower)) {
                    score += 20;
                }

                return { def, score };
            })
            .filter(item => item.score > 0)
            .sort((a, b) => b.score - a.score);

        // Show results
        if (rankedResults.length > 0) {
            searchResults.innerHTML = `
                <div class="space-y-4">
                    ${rankedResults.map(item => renderSearchResult(item.def, query)).join('')}
                </div>
            `;
        } else {
            searchResults.innerHTML = `
                <div class="text-center text-gray-500 p-4">
                    No results found for "${query}"
                </div>
            `;
        }
    } catch (error) {
        console.error('Error performing search:', error);
        searchResults.innerHTML = `
            <div class="text-red-500 p-4">
                Error performing search: ${error.message}
            </div>
        `;
    }
}
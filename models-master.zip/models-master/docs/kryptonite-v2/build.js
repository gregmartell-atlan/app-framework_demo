const fs = require('fs');
const path = require('path');

function walkDir(dir, callback) {
    fs.readdirSync(dir).forEach(f => {
        let dirPath = path.join(dir, f);
        let isDirectory = fs.statSync(dirPath).isDirectory();
        isDirectory ? walkDir(dirPath, callback) : callback(path.join(dir, f));
    });
}

const typeDefIndex = {
    entityDefs: []
};

const graphData = {
    nodes: [],
    edges: [],
    relationships: [] // Store relationship definitions
};

const processedNodes = new Set(); // Track unique nodes

function addNode(name, description, type = 'entity') {
    if (!processedNodes.has(name)) {
        graphData.nodes.push({
            id: name,
            label: name,
            description: description,
            type: type
        });
        processedNodes.add(name);
    }
}

function addEdge(from, to, type = 'inheritance', metadata = {}) {
    graphData.edges.push({
        from: from,
        to: to,
        type: type,
        relationshipCategory: metadata.relationshipCategory || type,
        ...metadata
    });
}

// Start from your atlas directory
walkDir('./atlas', (filePath) => {
    if (filePath.endsWith('.json')) {
        const content = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        
        if (content.entityDefs) {
            content.entityDefs.forEach(def => {
                // Add to typeDefIndex
                typeDefIndex.entityDefs.push({
                    name: def.name,
                    description: def.description,
                    path: filePath.replace(/^\.\//, '')
                });

                // Add node for the entity
                addNode(def.name, def.description);

                // Process superTypes (inheritance relationships)
                if (def.superTypes) {
                    def.superTypes.forEach(superType => {
                        addNode(superType, `Supertype of ${def.name}`);
                        addEdge(superType, def.name, 'inheritance');
                    });
                }

                // Process relationships
                if (content.relationshipDefs) {
                    content.relationshipDefs.forEach(rel => {
                        // Add relationship information
                        graphData.relationships.push({
                            name: rel.name,
                            description: rel.description,
                            relationshipCategory: rel.relationshipCategory || 'ASSOCIATION',
                            end1: {
                                type: rel.endDef1.type,
                                name: rel.endDef1.name,
                                cardinality: rel.endDef1.cardinality
                            },
                            end2: {
                                type: rel.endDef2.type,
                                name: rel.endDef2.name,
                                cardinality: rel.endDef2.cardinality
                            }
                        });

                        // Add nodes for both ends if they don't exist
                        addNode(rel.endDef1.type, `Entity type ${rel.endDef1.type}`);
                        addNode(rel.endDef2.type, `Entity type ${rel.endDef2.type}`);

                        // Add relationship edge
                        addEdge(rel.endDef1.type, rel.endDef2.type, 'relationship', {
                            name: rel.name,
                            relationshipCategory: rel.relationshipCategory || 'ASSOCIATION',
                            cardinality: `${rel.endDef1.cardinality}-${rel.endDef2.cardinality}`
                        });
                    });
                }

                // Process attribute relationships (references to other entities)
                if (def.attributeDefs) {
                    def.attributeDefs.forEach(attr => {
                        if (attr.typeName && attr.typeName.startsWith('array<') || attr.typeName.includes('Map<')) {
                            // Extract referenced type names from array/map types
                            const matches = attr.typeName.match(/[a-zA-Z_]+/g);
                            matches.forEach(referencedType => {
                                if (referencedType !== 'array' && referencedType !== 'Map') {
                                    addNode(referencedType, `Referenced type ${referencedType}`);
                                    addEdge(def.name, referencedType, 'reference', {
                                        name: attr.name,
                                        description: attr.description
                                    });
                                }
                            });
                        }
                    });
                }
            });
        }
    }
});

// Create a data directory if it doesn't exist
if (!fs.existsSync('data')) {
    fs.mkdirSync('data');
}

// Write the index to a separate JSON file
fs.writeFileSync('data/typedef-index.json', JSON.stringify(typeDefIndex, null, 2));

// Write the graph data to a separate JSON file
fs.writeFileSync('data/typedef-graph.json', JSON.stringify(graphData, null, 2)); 
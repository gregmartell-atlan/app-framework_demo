# modelsdoc

This section of python code generates HTML documentation for models which are later pushed to kryptonite.

- Run `poetry install` to install dependencies
- Run `poetry run main` to generate docs
- Run `poetry run dev` to generate docs and start a simple http server on the output path

```
usage: main [-h] [--output-prefix OUTPUT_PREFIX] [--branch-name BRANCH_NAME]

options:
  -h, --help            show this help message and exit
  --output-prefix OUTPUT_PREFIX, -o OUTPUT_PREFIX
                        Output Path Prefix
  --branch-name BRANCH_NAME, -b BRANCH_NAME
                        Current active branch of the models repository
```

import networkx
import shutil
import os
import argparse
import jinja2
import glob
import orjson
from typing import Dict, Any, Tuple

parser = argparse.ArgumentParser()
parser.add_argument(
    "--output-prefix",
    "-o",
    type=str,
    help="Output Path Prefix",
    default="/tmp/output/models",
)
parser.add_argument(
    "--branch-name",
    "-b",
    type=str,
    help="Current active branch of the models repository",
    default="master",
)


def read_all_models(
    path_prefix: str, branch_name: str
) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any]]:
    models = {
        "entityDefs": {},
        "enumDefs": {},
        "relationshipDefs": {},
        "structDefs": {},
    }

    file_path_map = {}
    attribute_name_index = {}

    for file in glob.glob(f"{path_prefix}/**/*.json", recursive=True):
        with open(file, "r") as f:
            m = orjson.loads(f.read())
            for k in models.keys():
                for x in m.get(k, []):
                    key = x.get("name") or x.get("displayName")
                    models[k][key] = x
                    file_path_map[f"{k}/{key}"] = file.replace(
                        "../../atlas",
                        f"https://github.com/atlanhq/models/blob/{branch_name}/atlas",
                    )

                    for attribute_def in models[k][key].get("attributeDefs", []):
                        name = attribute_def.get("name")
                        if name:
                            attribute_name_index[name] = f"{k}/{key}"

    return models, file_path_map, attribute_name_index


def main():
    args = parser.parse_args()
    models, file_path_map, attribute_name_index = read_all_models(
        "../../atlas", args.branch_name
    )

    entity_type_graph = networkx.DiGraph()

    for t in models["entityDefs"]:
        for super_type in models["entityDefs"][t].get("superTypes", []):
            entity_type_graph.add_edge(super_type, t)

    env = jinja2.Environment(loader=jinja2.FileSystemLoader("modelsdoc/templates"))

    helper_funcs = {
        "list": list,
        "set": set,
        "nx": networkx,
        "entity_type_graph": entity_type_graph,
        "sorted": sorted,
    }

    templates_map = {
        "entityDefs": "entity_def.jinja2",
        "enumDefs": "enum_def.jinja2",
        "relationshipDefs": "relationship_def.jinja2",
        "structDefs": "struct_def.jinja2",
    }

    os.makedirs(f"{args.output_prefix}/{args.branch_name}", exist_ok=True)

    template = env.get_template("index.jinja2")
    html = template.render(models=models, branch_name=args.branch_name, **helper_funcs)
    with open(f"{args.output_prefix}/{args.branch_name}/index.html", "w") as f:
        print(f"Wrote {f.name}")
        f.write(html)

    template = env.get_template("main.js")
    js = template.render(
        attribute_name_index=attribute_name_index,
        branch_name=args.branch_name,
        **helper_funcs,
    )
    with open(f"{args.output_prefix}/{args.branch_name}/main.js", "w") as f:
        print(f"Wrote {f.name}")
        f.write(js)

    for t, template_name in templates_map.items():
        os.makedirs(f"{args.output_prefix}/{args.branch_name}/{t}", exist_ok=True)
        template = env.get_template(template_name)

        for typedef_name in models[t]:
            try:
                html = template.render(
                    models=models,
                    branch_name=args.branch_name,
                    typedef_name=typedef_name,
                    file_path_map=file_path_map,
                    **helper_funcs,
                )

                with open(
                    f"{args.output_prefix}/{args.branch_name}/{t}/{typedef_name}.html", "w"
                ) as f:
                    f.write(html)
                    print(f"Wrote {f.name}")
            except Exception as e:
                print(f"Error rendering {t}/{typedef_name}: {e}")


if __name__ == "__main__":
    main()

let changeBranchInUrl = (from_branch, target_branch) => {
  let url = location.href
  url = url.replace(`/${from_branch}`, `/${target_branch}`)
  location.href = url
}

let index = {{ attribute_name_index | tojson }};
let indexKeys = Object.keys(index);

index.search = (id) => {
  return indexKeys.filter(x => x.toLowerCase().includes(id.toLowerCase())).map(x => [x, index[x]])
}

window.onload = () => {
  let collapsibles = document.getElementsByClassName("collapsible");

  for(let i = 0; i < collapsibles.length; i++) {
    let c = collapsibles[i];
    c.addEventListener("click", () => {
      let content = c.nextElementSibling;
      if (content.style.display != "none") {
        content.style.display = "none";
      } else {
        content.style.display = "block";
      }  
    })
  }

  let search_bar = document.getElementById('default-search')
  let search_result = document.getElementById('search-result')
  
  let search = (e) => {
    if (e.target.value == "") {
      search_result.innerHTML = ""
    } else {
      let r = index.search(e.target.value).map(
        x => `<li>
                <a class="block py-2 px-4 hover:bg-gray-100" target="_blank" href="https://kryptonite.atlan.dev/models/{{branch_name}}/${x[1]}.html#${x[1].split('/')[1]}/${x[0]}">
                  <span class="font-bold">${x[0]}</span>
                  <span class="text-blue-600 ml-4">${x[1]}</span>
                </a>
              </li>`
      )
  
      search_result.innerHTML = r.join("\n");
    }

  }

  search_bar.addEventListener('input', search)
}

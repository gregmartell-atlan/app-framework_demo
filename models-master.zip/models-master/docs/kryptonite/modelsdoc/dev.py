from modelsdoc.main import main
from multiprocessing import Process
from http.server import HTTPServer, SimpleHTTPRequestHandler

OUTPUT_DIRECTORY = "/tmp/output"


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=OUTPUT_DIRECTORY, **kwargs)


def start_dev_server():
    main()
    port = 1906
    print(f"Serving HTTP on {port}:: (http://[::]:{port}/)")
    s = HTTPServer(("", port), Handler)
    s.serve_forever()


if __name__ == "__main__":
    start_dev_server()
